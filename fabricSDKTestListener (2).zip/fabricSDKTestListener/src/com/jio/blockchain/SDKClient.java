package com.jio.blockchain;

import static java.lang.String.format;
import static java.nio.charset.StandardCharsets.UTF_8;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.regex.Pattern;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.SimpleLayout;
import org.hyperledger.fabric.sdk.BlockEvent;
import org.hyperledger.fabric.sdk.BlockEvent.TransactionEvent;
import org.hyperledger.fabric.sdk.ChaincodeEndorsementPolicy;
import org.hyperledger.fabric.sdk.ChaincodeEvent;
import org.hyperledger.fabric.sdk.ChaincodeEventListener;
import org.hyperledger.fabric.sdk.ChaincodeID;
import org.hyperledger.fabric.sdk.Channel;
import org.hyperledger.fabric.sdk.HFClient;
import org.hyperledger.fabric.sdk.InstallProposalRequest;
import org.hyperledger.fabric.sdk.InstantiateProposalRequest;
import org.hyperledger.fabric.sdk.Orderer;
import org.hyperledger.fabric.sdk.Peer;
import org.hyperledger.fabric.sdk.ProposalResponse;
import org.hyperledger.fabric.sdk.QueryByChaincodeRequest;
import org.hyperledger.fabric.sdk.TransactionProposalRequest;
import org.hyperledger.fabric.sdk.TransactionRequest.Type;
import org.hyperledger.fabric.sdk.UpgradeProposalRequest;
import org.hyperledger.fabric.sdk.exception.ChaincodeEndorsementPolicyParseException;
import org.hyperledger.fabric.sdk.exception.InvalidArgumentException;
import org.hyperledger.fabric.sdk.exception.ProposalException;
import org.hyperledger.fabric.sdk.exception.TransactionEventException;
import org.hyperledger.fabric.sdk.security.CryptoSuite;
import org.hyperledger.fabric.sdk.testutils.TestConfig;
import org.hyperledger.fabric.sdkintegration.Util;

import com.google.common.collect.Multiset.Entry;
import com.google.protobuf.ByteString;
import com.google.protobuf.Descriptors.FieldDescriptor;
import com.google.protobuf.InvalidProtocolBufferException;

public class SDKClient {

	private static final String CHANNEL_NAME = "mychannel";
	static HFClient hfclient = null;
	private static final String EXPECTED_EVENT_NAME = "event";
	private static final String USER_NAME = "admin";
	private static final String USER_MSP_ID = "jiomnpMSP";
	//private static final String USER_MSP_ID = "UserMSP";
	
	private static final String CHAIN_CODE_FILEPATH = "sdkintegration/gocc/sample1";
	private static final String CHAIN_CODE_NAME = "mnpCode8";
	private static final String CHAIN_CODE_PATH = "github.com/mnp";
	private static final String CHAIN_CODE_VERSION = "1";
	private static final String TEST_FIXTURES_PATH = "src/test/fixture";
	private static final String NODE_CHAIN_CODE_FILEPATH = "sdkintegration/nodecc/sample1";
	private static final String NODE_CHAIN_CODE_NAME = "mychaincodeNode3";
	private static final String NODE_CHAIN_CODE_PATH = ".";
	private static final String NODE_CHAIN_CODE_VERSION = "1.1";
	private static final String NODE_TEST_FIXTURES_PATH = "src/test/fixture";
	/*private static final String PEER1_ADDRESS = "grpc://10.64.217.120:7051";
	//private static final String ORDERER1_ADDRESS = "grpc://10.64.217.120:7050";*/
	private static final String PEER1_ADDRESS = "grpc://10.64.217.120:7051";
	private static final String PEER1_NAME = "do.jiomnp.com";
	//private static final String PEER1_NAME = "peer0.user.mnp1.com";
	//private static final String PEER2_ADDRESS = "grpc://10.64.217.120:8051";
	private static final String PEER2_ADDRESS = "grpc://10.64.253.213:9051";
	//private static final String PEER3_ADDRESS = "grpc://10.64.253.213:9051";
	private static final String PEER4_ADDRESS = "grpc://10.64.253.213:10051";
	//private static final String PEER2_NAME = "peer0.operator.mnp1.com";
	private static final String PEER2_NAME = "ro.jiomnp.com";
	private static final String PEER3_NAME = "peer0.org2.example.com";
	private static final String PEER4_NAME = "peer1.org2.example.com";
	private static final String ORDERER1_NAME = "orderer.example.com";
	//private static final String ORDERER1_NAME = "orderer.mnp1.com";
	private static final String ORDERER1_ADDRESS = "grpc://10.64.217.120:7050";
	//private static final String keystoreLocation = "C:\\Users\\vikash.agrawal\\Desktop\\hfc-key-store\\admin1\\keystore";
	//private static final String keystoreLocation = "C:\\Users\\vikash.agrawal\\Desktop\\mnp\\user1\\keystore";
	private static final String keystoreLocation = "C:\\BlockchainCerti";
	// private static final String usercertfile =
	// "C:\\Users\\vikash.agrawal\\Desktop\\hfc-key-store\\admin1\\Admin@org1.example.com-cert.";
	//private static final String usercertfile = "C:\\Users\\vikash.agrawal\\Desktop\\mnp\\user1\\signcerts\\User1@user.mnp1.com-cert.pem";
	//private static final String usercertfile = "C:\\Users\\vikash.agrawal\\Desktop\\mnp\\user1\\signcerts\\User1@org1.example.com-cert.pem";
	private static final String usercertfile = "C:\\BlockchainCerti\\Admin@jiomnp.com-cert.pem";
	private static final String orgName = "jiomnp.com";
	//private static final String orgName = "org1.example.com";
	
	
	
	public static void main(String[] args) {

		 class ChaincodeEventCapture implements ChaincodeEventListener { //A test class to capture chaincode events
	            final String handle;
	            final BlockEvent blockEvent;
	            final ChaincodeEvent chaincodeEvent;

	            ChaincodeEventCapture(String handle, BlockEvent blockEvent, ChaincodeEvent chaincodeEvent) {
	                this.handle = handle;
	                this.blockEvent = blockEvent;
	                this.chaincodeEvent = chaincodeEvent;
	            }

				@Override
				public void received(String handle, BlockEvent blockEvent, ChaincodeEvent chaincodeEvent) {
					System.out.println(handle);
				
					
				}
	        }
		try {
			System.out.println("initialize logger");
			Logger logger = Logger.getLogger(SDKClient.class);
			logger.getRoot().addAppender(new ConsoleAppender(new SimpleLayout()));
			logger.setLevel(Level.DEBUG);
			System.out.println("creating hf client");
			int i =11001;
		
				TimeUnit.MILLISECONDS.sleep(100);
			hfclient = HFClient.createNewInstance();
		
			File tempFile = File.createTempFile("teststore", "properties");

			tempFile.deleteOnExit();

			File sampleStoreFile = new File(System.getProperty("user.home") + "/test.properties");

			if (sampleStoreFile.exists()) { // For testing start fresh
				sampleStoreFile.delete();
			}
			logger.info("creating store object");
			final SDKStore sdkStore = new SDKStore(sampleStoreFile);

			// src/test/fixture/sdkintegration/e2e-2Orgs/channel/crypto-config/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp/keystore/

			// SampleUser someTestUSER = sampleStore.getMember("someTestUSER",
			// "someTestORG");
			// SampleUser someTestUSER = sampleStore.getMember("someTestUSER",
			// "someTestORG", "mspid",
			// findFileSk("src/test/fixture/sdkintegration/e2e-2Orgs/channel/crypto-config/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp/keystore"),
			// new
			// File("src/test/fixture/sdkintegration/e2e-2Orgs/channel/crypto-config/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp/signcerts/Admin@org1.example.com-cert.pem"));
			//
			
			 /** SampleUser someTestUSER = sampleStore.getMember("User1",
			 * "org1.example.com", "Org1MSP",
			 * findFileSk("C:\\Users\\vikash.agrawal\\Desktop\\hfc-key-store"),
			 * new File(
			 * "C:\\Users\\vikash.agrawal\\Desktop\\hfc-key-store\\User1@org1.example.com-cert.pem"
			 * ));
			 */

			logger.info("creating sdk user object");
			SDKUser someTestUSER = sdkStore.getMember(USER_NAME, orgName, USER_MSP_ID,
					findFileSk(keystoreLocation), new File(usercertfile));
			
			someTestUSER.setMspId(USER_MSP_ID);

			hfclient.setCryptoSuite(CryptoSuite.Factory.getCryptoSuite());
			hfclient.setUserContext(someTestUSER);
			
			logger.info("creating sdk user object");
			
			Channel testChannel = hfclient.newChannel(CHANNEL_NAME);
			// Channel testChannel = hfclient.getChannel(CHANNEL_NAME);
			System.out.println("joining channel");

			Peer peer1 = hfclient.newPeer(PEER1_NAME, PEER1_ADDRESS);
		//	Peer peer2 = hfclient.newPeer(PEER2_NAME, PEER2_ADDRESS);
		//	Peer peer3 = hfclient.newPeer(PEER3_NAME, PEER3_ADDRESS);
			//Peer peer4 = hfclient.newPeer(PEER4_NAME, PEER4_ADDRESS);
			Orderer orderer = hfclient.newOrderer(ORDERER1_NAME, ORDERER1_ADDRESS);
			System.out.println("adding peer "+PEER1_NAME);
			testChannel.addPeer(peer1);

		//	testChannel.addPeer(peer2);
			//testChannel.addPeer(peer3);
			//testChannel.addPeer(peer4);
			System.out.println("adding orderer "+ORDERER1_NAME);
			testChannel.addOrderer(orderer);
	
			
			logger.info("Channel intialized successfully");
			// QueryByChaincodeRequest queryByChaincodeRequest =
			// queryAllcars();
			/**
			 * query for particular car
			 * queryByChaincodeRequest.setFcn("queryCar");
			 * queryByChaincodeRequest.setArgs("CAR4");
			 */
			// changeCarOwner(testChannel, "CAR9", "Dave");
			/*
			 * Collection<ProposalResponse> collection =
			 * testChannel.queryByChaincode(queryByChaincodeRequest);
			 * Iterator<ProposalResponse> iterator = collection.iterator();
			 * while (iterator.hasNext()) { ProposalResponse proposalResponse =
			 * iterator.next(); System.out.println("Quesry response");
			 * System.out.println(new
			 * String(proposalResponse.getPayloadBytes().toByteArray()));
			 * System.out.println(proposalResponse.getMessage());
			 * System.out.println(proposalResponse.getChaincodeID());
			 * System.out.println(proposalResponse.getPayloadBytes());
			 * System.out.println(proposalResponse.getPeer()); }
			 */ testChannel.initialize();
			 
			//createChainCodeGo(testChannel);
		//instantiateChaincode(testChannel);
		
			// createChainCodeJava(testChannel);
			// createChainCodeNode(testChannel);
			 //instantiateChaincodeNode(testChannel);
		
			 
			//client.instantiateChaincode( chainCodeDetail, "commonchannel");
			String json = "{\"test\":\"12345\"}";
			 /*testChannel.registerBlockListener(blockevent -> {
	 				try {
	 					System.out.println("in the block listener Data count +++++++++++++++++++++++++"
	 							+ blockevent.getBlock().getData().getDataCount());
	 					System.out.println(	"size here =>"+testChannel.getEventHubs().size());
	 				//	System.out.println("in here------- "+blockevent.getTransactionEvents().iterator().next().getTransactionActionInfos().iterator().next().getEvent());
	 					System.out.println(" Block number +++++++++++++++++++++++++" + blockevent.getBlockNumber());

	 					System.out.println(" channel id +++++++++++++++++++++++++" + blockevent.getChannelId());
	 					if (blockevent.getEventHub() != null)
	 						System.out.println(
	 								" Eventhub name +++++++++++++++++++++++++ " + blockevent.getEventHub().getName());

	 					System.out.println(" Peer name +++++++++++++++++++++++++ " + blockevent.getPeer());
	 					if (blockevent.getTransactionEvents().iterator().hasNext())
	 						System.out.println(" Transaction id name +++++++++++++++++++++++++ "
	 								+ blockevent.getTransactionEvents().iterator().next().getTransactionID());
	 					System.out.println(" Transaction  name +++++++++++++++++++++++++ "
								+ blockevent.getTransactionEvents().iterator().next().getTransactionActionInfos().iterator().next().getResponseMessage());
	 					System.out.println(" data list +++++++++++++++++++++++++" + blockevent.getBlock().getData().getDataList());
	 					
	 					blockevent.getBlock().getData().getAllFields().entrySet();
						for(java.util.Map.Entry<FieldDescriptor,Object> tx : blockevent.getBlock().getData().getAllFields().entrySet()){
							System.out.println("here");
							System.out.println(new String(blockevent.getTransactionEvents().iterator().next().getTransactionActionInfos().iterator().next().getChaincodeInputArgs(0)));
							System.out.println(blockevent.getTransactionEvents().iterator().next().getTransactionActionInfos().iterator().next().getProposalResponseStatus());
							System.out.println(tx.getKey());
							//System.out.println(((List<ByteString>)tx.getValue()).iterator().next().toString(UTF_8));
							System.out.println("=========================================/n");
						}
						
	 					for(ByteString s : blockevent.getBlock().getData().getDataList()){
	 						System.out.println("size "+blockevent.getBlock().getData().getDataList().size());
	 						//System.out.println("in map+_------------"+blockevent.getBlock().getData().getAllFields());
	 						//for(Entry)
	 						
	 						//System.out.println(s.toStringUtf8());
	 						
	 					}
	 					
	 				} catch (InvalidProtocolBufferException e) {
	 					// TODO Auto-generated catch block
	 					e.printStackTrace();
	 				}
	 			});*/
			
		/*	
	        Vector<ChaincodeEventCapture> chaincodeEvents = new Vector<>();
	
					
					//testChannel.registerChaincodeEventListener("b83d638fe0a5742c275345b28ce89d70f0ca9300eaa0bf88b67b29cd1a90eb3b", "getAllTransactionForNumber", tx);
					
					
				 testChannel.registerChaincodeEventListener(Pattern.compile(CHAIN_CODE_NAME),
		                     Pattern.compile(Pattern.quote("*")),
		                     (handle, blockEvent, chaincodeEvent) -> {
		                    	 System.out.println("IN HERE================");
		                         chaincodeEvents.add(new ChaincodeEventCapture(handle, blockEvent, chaincodeEvent));

		                         String es = blockEvent.getPeer() != null ? blockEvent.getPeer().getName() : blockEvent.getEventHub().getName();
		                         String res ="RECEIVED Chaincode event with handle: %s, chaincode Id: %s, chaincode event name: %s, "
		                                         + "transaction id: %s, event payload: \"%s\", from eventhub: %s"+
		                                 handle+ chaincodeEvent.getChaincodeId()+                                 chaincodeEvent.getEventName()+
		                                 chaincodeEvent.getTxId()+
		                                 new String(chaincodeEvent.getPayload())+ es;
		                         System.out.println(res);

		                     });
					
					
				    
			  
			*/
				//upgradeChaincodeNode(testChannel);
			 //  initLedger(testChannel, new String[]{""});
			//testChannel.registerChaincodeEventListener(chaincodeId, eventName, chaincodeEventListener)
			//recordUPCGeneratin(testChannel,new String[]{""+i,json});
			//i++;
			
		      /*Collection<ProposalResponse> responses;
              final Collection<ProposalResponse> successful = new LinkedList<>();
              final Collection<ProposalResponse> failed = new LinkedList<>();
              Collection<Peer> peersFromOrg = testChannel.getPeers();
             Collection<EventHub> hub= testChannel.getEventHubs();
             
             
             final String blockListenerHandle = testChannel.registerBlockListener(blockevent -> {
 				try {
 					System.out.println("in the block listener Data count +++++++++++++++++++++++++"
 							+ blockevent.getBlock().getData().getDataCount());
 					System.out.println(" Block number +++++++++++++++++++++++++" + blockevent.getBlockNumber());

 					System.out.println(" channel id +++++++++++++++++++++++++" + blockevent.getChannelId());
 					if (blockevent.getEventHub() != null)
 						System.out.println(
 								" Eventhub name +++++++++++++++++++++++++ " + blockevent.getEventHub().getName());

 					System.out.println(" Peer name +++++++++++++++++++++++++ " + blockevent.getPeer());
 					if (blockevent.getTransactionEvents().iterator().hasNext())
 						System.out.println(" Transaction id name +++++++++++++++++++++++++ "
 								+ blockevent.getTransactionEvents().iterator().next().getTransactionID());
 					System.out.println(" data list +++++++++++++++++++++++++" + blockevent.getBlock().getData().getDataList());
 				} catch (InvalidProtocolBufferException e) {
 					// TODO Auto-generated catch block
 					e.printStackTrace();
 				}
 			});
             Vector<ChaincodeEventCapture> chaincodeEvents = new Vector<>();
             String chaincodeEventListenerHandle = testChannel.registerChaincodeEventListener(Pattern.compile(".*"),
                     Pattern.compile(Pattern.quote(EXPECTED_EVENT_NAME)),
                     (handle, blockEvent, chaincodeEvent) -> {

                         chaincodeEvents.add(new ChaincodeEventCapture(handle, blockEvent, chaincodeEvent));

                         String es = blockEvent.getPeer() != null ? blockEvent.getPeer().getName() : blockEvent.getEventHub().getName();
                         String res ="RECEIVED Chaincode event with handle: %s, chaincode Id: %s, chaincode event name: %s, "
                                         + "transaction id: %s, event payload: \"%s\", from eventhub: %s"+
                                 handle+ chaincodeEvent.getChaincodeId()+                                 chaincodeEvent.getEventName()+
                                 chaincodeEvent.getTxId()+
                                 new String(chaincodeEvent.getPayload())+ es;
                         System.out.println(res);

                     });*/
          // genUPCC(testChannel, new String[]{"9987571450"});
            
         //    portNo(testChannel, new String[]{"9987571450","12345","Jio"});
             
          //  getHistoryForNumber(testChannel, new String[]{"9987571450"});
            
          //QueryByChaincodeRequest queryByChaincodeRequest2 = queryNodeChaincode(testChannel);
		/*	QueryByChaincodeRequest queryByChaincodeRequest2 =queryOp("9987571450");
			Collection<ProposalResponse> collection2 = testChannel.queryByChaincode(queryByChaincodeRequest2);
			Iterator<ProposalResponse> iterator2 = collection2.iterator();
			while (iterator2.hasNext()) {
				ProposalResponse proposalResponse = iterator2.next();
				System.out.println("Quesry response");
				System.out.println(new String(proposalResponse.getPayloadBytes().toByteArray()));
				System.out.println(proposalResponse.getMessage());
				System.out.println(proposalResponse.getChaincodeID());
				System.out.println(proposalResponse.getPayloadBytes());
				System.out.println(proposalResponse.getPeer());
			}*/

			// Assert.assertTrue(peer != null);
		
            
             //For non foo channel unregister event listener to test events are not called.
            /* if (!testChannel) {
                 channel.unRegisterChaincodeEventListener(chaincodeEventListenerHandle);
                 chaincodeEventListenerHandle = null;

             }*/
             
             /*	genUPCC(testChannel, new String[]{"9987571450"});.thenApply((BlockEvent.TransactionEvent transactionEvent) -> {
		
			
				UpgradeProposalRequest upgradeProposalRequest = hfclient.newUpgradeProposalRequest();
				upgradeProposalRequest.setChaincodeName(CHAIN_CODE_NAME);
				upgradeProposalRequest.setChaincodePath("github.com/mnp");
				upgradeProposalRequest.setArgs("");
				upgradeProposalRequest.setChaincodeLanguage(Type.GO_LANG);
				upgradeProposalRequest.setChaincodeVersion(CHAIN_CODE_VERSION);
				Map<String, byte[]> tm = new HashMap<>();
				tm.put("HyperLedgerFabric", "UpgradeProposalRequest:JavaSDK".getBytes(UTF_8));
				tm.put("method", "UpgradeProposalRequest".getBytes(UTF_8));
				upgradeProposalRequest.setTransientMap(tm);
				upgradeProposalRequest.setProposalWaitTime(TestConfig.getConfig().getProposalWaitTime());
				upgradeProposalRequest.setTransientMap(tm);
				ChaincodeEndorsementPolicy chaincodeEndorsementPolicy = new ChaincodeEndorsementPolicy();
				chaincodeEndorsementPolicy
						.fromYamlFile(new File(TEST_FIXTURES_PATH + "/sdkintegration/chaincodeendorsementpolicy.yaml"));
				upgradeProposalRequest.setChaincodeEndorsementPolicy(chaincodeEndorsementPolicy);
				Collection<ProposalResponse> proposalResponse = testChannel
						.sendUpgradeProposal(upgradeProposalRequest);
				
				Iterator<ProposalResponse> iterator = proposalResponse.iterator();
				while (iterator.hasNext()) {
					ProposalResponse proposalResponse2 = iterator.next();
					System.out.println(new String(proposalResponse2.getPayloadBytes().toByteArray()));
					System.out.println(proposalResponse2.getMessage());
					System.out.println(proposalResponse2.getChaincodeID());
					System.out.println(proposalResponse2.getPayloadBytes());
					  if (proposalResponse2.getStatus() == Status.SUCCESS) {
	                         successful.add(proposalResponse2);
	                     } else {
	                         failed.add(proposalResponse2);
	                     }
				}
				if (failed.size() > 0) {
                    ProposalResponse first = failed.iterator().next();
                    throw new AssertionError("Not enough endorsers for upgrade :"
                            + successful.size() + ".  " + first.getMessage());
                }
			});*/
			
        

    
			
			//portNo(testChannel, new String[]{"9987571451","12345","newvasod"});
			
			   
				String json1 = "{\"MNP_ID\":\"12345\",\"mobile_no\":\"9812345690\",\"subscriber_UUID\":\"A12345\"}";
				genUPCC(testChannel,new String[]{"9812345692"+i,json});
				//String json2 = "{\"Customer_Segment\":\"Prepaid\",\"eKYC_Status\":\"Pending\",\"Contractual_Obligation\":\"No\",\"Corporate_connection\":\"No\",\"Network_Ageing\":\"27\",\"Under Processing\":\"No\",\"Payments_Due\":\"0\",\"Sub_judice\":\"No\",\"Prohibited\":\"No\",\"LEA_flag\":\"No\",\"Aadhar_Number\":\"valid UIDAI\"}";
				// String json3= "{\"testnewkey\":\"ShobhitChanged\",\"testnewkeynewste\":\"TestChanged\"}";

				//client.AddPeer(Peername, PeerAddress);
				//String[] test ={};
				//client.initCommonLedger(test,"commonchannel");
				//client.initCommonLedger(test,"machannel");
				/*while (true){
				genUPCC(testChannel,new String[]{"9812345692"+i++,json1});
				//client.recordUPCGeneratin(new String[]{"9812345691",json1}, "testChannel");
				}*/
		}catch (Exception e) {
			System.out.println(e);
		}
	}

	public  static CompletableFuture<BlockEvent.TransactionEvent> recordUPCGeneratin(Channel testChannel, String[] args ) 
			throws ProposalException, InvalidArgumentException {
		TransactionProposalRequest transactionProposalRequest = hfclient.newTransactionProposalRequest();
		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName(CHAIN_CODE_NAME).build();
		transactionProposalRequest.setChaincodeID(chaincodeID);
		transactionProposalRequest.setFcn("recordUPCgeneration");
		transactionProposalRequest.setArgs(args);
		Collection<ProposalResponse> proposalResponses = testChannel
				.sendTransactionProposal(transactionProposalRequest);
		return testChannel.sendTransaction(proposalResponses, hfclient.getUserContext());
	}
	
	private static void initLedger(Channel testChannel, String[] args) throws ProposalException, InvalidArgumentException {
		TransactionProposalRequest transactionProposalRequest = hfclient.newTransactionProposalRequest();
		

		transactionProposalRequest.setFcn("initLedger");

		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName(CHAIN_CODE_NAME).build();

		transactionProposalRequest.setChaincodeID(chaincodeID);

		transactionProposalRequest.setArgs(args);
		// transactionProposalRequest.setArgs("CAR11", "Chevy1", "Volt1",
		// "Red1", "Nick1");

		Collection<ProposalResponse> proposalResponses = testChannel
				.sendTransactionProposal(transactionProposalRequest);

		CompletableFuture<TransactionEvent>  completableFuture =testChannel.sendTransaction(proposalResponses, hfclient.getUserContext());
		
		
	}

	private static QueryByChaincodeRequest queryMychaincode() {
		QueryByChaincodeRequest queryByChaincodeRequest = QueryByChaincodeRequest
				.newInstance(hfclient.getUserContext());
		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName(CHAIN_CODE_NAME).build();
		queryByChaincodeRequest.setChaincodeID(chaincodeID);
		queryByChaincodeRequest.setArgs("B");
		queryByChaincodeRequest.setFcn("query");
		return queryByChaincodeRequest;

	}

	public static void createChainCodeGo(Channel testChannel)
			throws InvalidArgumentException, ProposalException, IOException {
		InstallProposalRequest installProposalRequest = hfclient.newInstallProposalRequest();

		installProposalRequest.setChaincodeLanguage(Type.GO_LANG);
		installProposalRequest.setChaincodeVersion(CHAIN_CODE_VERSION);

		String chaincodeEventListenerHandle = testChannel.registerChaincodeEventListener(Pattern.compile(".*"),
				Pattern.compile(Pattern.quote(EXPECTED_EVENT_NAME)), new ChaincodeEventListenerImpl());
		installProposalRequest.setChaincodeName(CHAIN_CODE_NAME);

		// ChaincodeID chaincodeID =
		// ChaincodeID.newBuilder().setName("mychaincode").build();

		// installProposalRequest.setChaincodeID(chaincodeID);

		// installProposalRequest.setChaincodePath(
		// Paths.get("C:\\Users\\vikash.agrawal\\Desktop\\fabric-sdk-java\\src\\test\\fixture\\sdkintegration\\gocc\\sample1\\src\\github.com\\example_cc\\example_cc.go").toString());
		// installProposalRequest.setChaincodeInputStream(new
		// FileInputStream(
		// "C:\\Users\\vikash.agrawal\\Desktop\\fabric-sdk-java\\src\\test\\fixture\\sdkintegration\\gocc\\sample1\\src\\github.com\\example_cc\\example_cc.go"));
		// installProposalRequest.setChaincodeSourceLocation(new
		// File("src/org/hyperledger/fabric/sdk/ChainCodeImpl.java"));
		File file = new File("src/test/fixture/sdkintegration/gocc/sample1");
		System.out.println("file exists " + file.exists());
		System.out.println(Paths.get(TEST_FIXTURES_PATH, CHAIN_CODE_FILEPATH, "src", CHAIN_CODE_PATH));
		installProposalRequest.setChaincodePath("github.com/mnp");
		// installProposalRequest.setChaincodeSourceLocation(file);
		/*
		 * installProposalRequest.setChaincodeInputStream(Util.
		 * generateTarGzInputStream( Paths.get(file.toString()).toFile(),
		 * "/chaincode/input/src/github.com/example_cc"));
		 */
		installProposalRequest.setChaincodeInputStream(Util.generateTarGzInputStream(
				(Paths.get(TEST_FIXTURES_PATH, CHAIN_CODE_FILEPATH, "src", CHAIN_CODE_PATH).toFile()),
				Paths.get("src", CHAIN_CODE_PATH).toString()));
		// installProposalRequest.setChaincodeInputStream(Util.generateTarGzInputStream(
		// (Paths.get(TEST_FIXTURES_PATH, CHAIN_CODE_FILEPATH, "src",
		// CHAIN_CODE_PATH).toFile()),
		// Paths.get("src", CHAIN_CODE_PATH).toString()));
		/*
		 * installProposalRequest
		 * .setChaincodeSourceLocation(Paths.get(TEST_FIXTURES_PATH,
		 * CHAIN_CODE_FILEPATH).toFile());
		 */

		Collection<ProposalResponse> proposalResponse = testChannel.sendInstallProposal(installProposalRequest);

		Iterator<ProposalResponse> iterator = proposalResponse.iterator();

		while (iterator.hasNext()) {
			ProposalResponse proposalResponse2 = iterator.next();
			System.out.println(new String(proposalResponse2.getPayloadBytes().toByteArray()));
			System.out.println(proposalResponse2.getMessage());
			System.out.println(proposalResponse2.getChaincodeID());
			System.out.println(proposalResponse2.getPayloadBytes());

		}
	}

	public static QueryByChaincodeRequest queryNodeChaincode(Channel testChannel) {
		QueryByChaincodeRequest queryByChaincodeRequest = QueryByChaincodeRequest
				.newInstance(hfclient.getUserContext());
		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName(NODE_CHAIN_CODE_NAME).build();
		queryByChaincodeRequest.setChaincodeID(chaincodeID);
		queryByChaincodeRequest.setArgs("B");
		queryByChaincodeRequest.setFcn("query");
		return queryByChaincodeRequest;
	}

	public static void createChainCodeNode(Channel testChannel)
			throws InvalidArgumentException, ProposalException, IOException {
		InstallProposalRequest installProposalRequest = hfclient.newInstallProposalRequest();

		installProposalRequest.setChaincodeLanguage(Type.NODE);
		installProposalRequest.setChaincodeVersion(CHAIN_CODE_VERSION);

		String chaincodeEventListenerHandle = testChannel.registerChaincodeEventListener(Pattern.compile(".*"),
				Pattern.compile(Pattern.quote(EXPECTED_EVENT_NAME)), new ChaincodeEventListenerImpl());
		installProposalRequest.setChaincodeName(NODE_CHAIN_CODE_NAME);

		// ChaincodeID chaincodeID =
		// ChaincodeID.newBuilder().setName("mychaincode").build();

		// installProposalRequest.setChaincodeID(chaincodeID);

		// installProposalRequest.setChaincodePath(
		// Paths.get("C:\\Users\\vikash.agrawal\\Desktop\\fabric-sdk-java\\src\\test\\fixture\\sdkintegration\\gocc\\sample1\\src\\github.com\\example_cc\\example_cc.go").toString());
		// installProposalRequest.setChaincodeInputStream(new
		// FileInputStream(
		// "C:\\Users\\vikash.agrawal\\Desktop\\fabric-sdk-java\\src\\test\\fixture\\sdkintegration\\gocc\\sample1\\src\\github.com\\example_cc\\example_cc.go"));
		// installProposalRequest.setChaincodeSourceLocation(new
		// File("src/org/hyperledger/fabric/sdk/ChainCodeImpl.java"));
		File file = new File("src/test/fixture/sdkintegration/gocc/sample1");
		System.out.println("file exists " + file.exists());
		System.out.println(Paths.get(NODE_TEST_FIXTURES_PATH, NODE_CHAIN_CODE_FILEPATH, "src", NODE_CHAIN_CODE_PATH));

		// installProposalRequest.setChaincodeSourceLocation(file);
		/*
		 * installProposalRequest.setChaincodeInputStream(Util.
		 * generateTarGzInputStream( Paths.get(file.toString()).toFile(),
		 * "/chaincode/input/src/github.com/example_cc"));
		 */
		installProposalRequest.setChaincodeInputStream(
				Util.generateTarGzInputStream((Paths.get(NODE_TEST_FIXTURES_PATH, NODE_CHAIN_CODE_FILEPATH).toFile()),
						Paths.get("src", NODE_CHAIN_CODE_PATH).toString()));
		// installProposalRequest.setChaincodeInputStream(Util.generateTarGzInputStream(
		// (Paths.get(TEST_FIXTURES_PATH, CHAIN_CODE_FILEPATH, "src",
		// CHAIN_CODE_PATH).toFile()),
		// Paths.get("src", CHAIN_CODE_PATH).toString()));
		/*
		 * installProposalRequest
		 * .setChaincodeSourceLocation(Paths.get(TEST_FIXTURES_PATH,
		 * CHAIN_CODE_FILEPATH).toFile());
		 */

		Collection<ProposalResponse> proposalResponse = testChannel.sendInstallProposal(installProposalRequest);

		Iterator<ProposalResponse> iterator = proposalResponse.iterator();

		while (iterator.hasNext()) {
			ProposalResponse proposalResponse2 = iterator.next();
			System.out.println(new String(proposalResponse2.getPayloadBytes().toByteArray()));
			System.out.println(proposalResponse2.getMessage());
			System.out.println(proposalResponse2.getChaincodeID());
			System.out.println(proposalResponse2.getPayloadBytes());

		}
	}

	public static void createChainCodeJava(Channel testChannel)
			throws InvalidArgumentException, ProposalException, IOException {
		InstallProposalRequest installProposalRequest = hfclient.newInstallProposalRequest();

		installProposalRequest.setChaincodeLanguage(Type.JAVA);
		installProposalRequest.setChaincodeVersion(CHAIN_CODE_VERSION);

		installProposalRequest.setChaincodeName(CHAIN_CODE_NAME);

		// ChaincodeID chaincodeID =
		// ChaincodeID.newBuilder().setName("mychaincode").build();

		// installProposalRequest.setChaincodeID(chaincodeID);

		// installProposalRequest.setChaincodePath(
		// Paths.get("C:\\Users\\vikash.agrawal\\Desktop\\fabric-sdk-java\\src\\test\\fixture\\sdkintegration\\gocc\\sample1\\src\\github.com\\example_cc\\example_cc.go").toString());
		// installProposalRequest.setChaincodeInputStream(new
		// FileInputStream(
		// "C:\\Users\\vikash.agrawal\\Desktop\\fabric-sdk-java\\src\\test\\fixture\\sdkintegration\\gocc\\sample1\\src\\github.com\\example_cc\\example_cc.go"));
		// installProposalRequest.setChaincodeSourceLocation(new
		// File("src/org/hyperledger/fabric/sdk/ChainCodeImpl.java"));
		File file = new File("/src/org/hyperledger/fabric/sdk/ChainCodeImpl.java");
		System.out.println("file exists " + file.exists());
		System.out.println(Paths.get(TEST_FIXTURES_PATH, CHAIN_CODE_FILEPATH, "src", CHAIN_CODE_PATH));

		installProposalRequest.setChaincodeInputStream(
				Util.generateTarGzInputStream((Paths.get(TEST_FIXTURES_PATH, CHAIN_CODE_FILEPATH).toFile()), "src"));
		/*
		 * installProposalRequest.setChaincodeInputStream(Util.
		 * generateTarGzInputStream( Paths.get(file.toString()).toFile(),
		 * "/chaincode/input/src/github.com/example_cc"));
		 */
		/*
		 * installProposalRequest.setChaincodeInputStream(Util.
		 * generateTarGzInputStream( (Paths.get(TEST_FIXTURES_PATH,
		 * CHAIN_CODE_FILEPATH, "src", CHAIN_CODE_PATH).toFile()),
		 * Paths.get("src", CHAIN_CODE_PATH).toString()));
		 */
		// installProposalRequest.setChaincodeInputStream(Util.generateTarGzInputStream(
		// (Paths.get(TEST_FIXTURES_PATH, CHAIN_CODE_FILEPATH, "src",
		// CHAIN_CODE_PATH).toFile()),
		// Paths.get("src", CHAIN_CODE_PATH).toString()));
		/*
		 * installProposalRequest
		 * .setChaincodeSourceLocation(Paths.get(TEST_FIXTURES_PATH,
		 * CHAIN_CODE_FILEPATH).toFile());
		 */
		installProposalRequest.setChaincodePath(null);
		Collection<ProposalResponse> proposalResponse = testChannel.sendInstallProposal(installProposalRequest);

		Iterator<ProposalResponse> iterator = proposalResponse.iterator();

		while (iterator.hasNext()) {
			ProposalResponse proposalResponse2 = iterator.next();
			System.out.println(new String(proposalResponse2.getPayloadBytes().toByteArray()));
			System.out.println(proposalResponse2.getMessage());
			System.out.println(proposalResponse2.getChaincodeID());
			System.out.println(proposalResponse2.getPayloadBytes());

		}
	}

	public static void instantiateChaincode(Channel testChannel)
			throws InvalidArgumentException, ProposalException, ChaincodeEndorsementPolicyParseException, IOException,
			InterruptedException, ExecutionException, TimeoutException {
		InstantiateProposalRequest instantiateProposalRequest = hfclient.newInstantiationProposalRequest();
		instantiateProposalRequest.setChaincodeName(CHAIN_CODE_NAME);
		instantiateProposalRequest.setChaincodePath("github.com/mnp");
		instantiateProposalRequest.setArgs("A", "100", "B", "200");
		instantiateProposalRequest.setChaincodeLanguage(Type.GO_LANG);
		instantiateProposalRequest.setChaincodeVersion(CHAIN_CODE_VERSION);
		Map<String, byte[]> tm = new HashMap<>();
		tm.put("HyperLedgerFabric", "InstantiateProposalRequest:JavaSDK".getBytes(UTF_8));
		tm.put("method", "InstantiateProposalRequest".getBytes(UTF_8));
		instantiateProposalRequest.setTransientMap(tm);
		instantiateProposalRequest.setProposalWaitTime(TestConfig.getConfig().getProposalWaitTime());
		instantiateProposalRequest.setTransientMap(tm);
		ChaincodeEndorsementPolicy chaincodeEndorsementPolicy = new ChaincodeEndorsementPolicy();
		chaincodeEndorsementPolicy
				.fromYamlFile(new File(TEST_FIXTURES_PATH + "/sdkintegration/chaincodeendorsementpolicy.yaml"));
		instantiateProposalRequest.setChaincodeEndorsementPolicy(chaincodeEndorsementPolicy);
		Collection<ProposalResponse> proposalResponse = testChannel
				.sendInstantiationProposal(instantiateProposalRequest);

		Iterator<ProposalResponse> iterator = proposalResponse.iterator();

		while (iterator.hasNext()) {
			ProposalResponse proposalResponse2 = iterator.next();
			System.out.println(new String(proposalResponse2.getPayloadBytes().toByteArray()));
			System.out.println(proposalResponse2.getMessage());
			System.out.println(proposalResponse2.getChaincodeID());
			System.out.println(proposalResponse2.getPayloadBytes());

		}

		TestConfig testConfig = TestConfig.getConfig();

		testChannel.sendTransaction(proposalResponse, hfclient.getUserContext()).thenApply(transactionEvent -> {
			try {

				assertTrue(transactionEvent.isValid()); // must be valid to be
														// here.
				System.out
						.println("Finished transaction with transaction id %s " + transactionEvent.getTransactionID());
				String testTxID = transactionEvent.getTransactionID(); // used
																		// in
																		// the
				// channel
				// queries later

				////////////////////////////
				// Send Query Proposal to all peers
				//
				//int delta = 30;
				//String expect = "" + (300 + delta);
				System.out.println("Now query chaincode for the value of b.");
				QueryByChaincodeRequest queryByChaincodeRequest = hfclient.newQueryProposalRequest();
				ChaincodeID chaincodeID= ChaincodeID.newBuilder().setName(CHAIN_CODE_NAME).build();
		
				queryByChaincodeRequest.setArgs(new String[] { "9987571451" });
				queryByChaincodeRequest.setFcn("getOP");
				//queryByChaincodeRequest.setChaincodeName(CHAIN_CODE_NAME);
				queryByChaincodeRequest.setChaincodeID(chaincodeID);
				Map<String, byte[]> tm2 = new HashMap<>();
				tm2.put("HyperLedgerFabric", "QueryByChaincodeRequest:JavaSDK".getBytes(UTF_8));
				tm2.put("method", "QueryByChaincodeRequest".getBytes(UTF_8));
				queryByChaincodeRequest.setTransientMap(tm2);

				Collection<ProposalResponse> queryProposals = testChannel.queryByChaincode(queryByChaincodeRequest);
				for (ProposalResponse proposalResponse2 : queryProposals) {
					if (!proposalResponse2.isVerified()
							|| proposalResponse2.getStatus() != ProposalResponse.Status.SUCCESS) {
						fail("Failed query proposal from peer " + proposalResponse2.getPeer().getName() + " status: "
								+ proposalResponse2.getStatus() + ". Messages: " + proposalResponse2.getMessage()
								+ ". Was verified : " + proposalResponse2.isVerified());
					} else {
						String payload = proposalResponse2.getProposalResponse().getResponse().getPayload()
								.toStringUtf8();
						System.out.println(
								"Query payload of b from peer %s returned  " + proposalResponse2.getPeer().getName());
						//assertEquals(payload, expect);
					}
				}

				return null;
			} catch (Exception e) {
				System.err.println("Caught exception while running query");
				e.printStackTrace();
				fail("Failed during chaincode query with error : " + e.getMessage());
			}

			return null;
		}).exceptionally(e -> {
			if (e instanceof TransactionEventException) {
				BlockEvent.TransactionEvent te = ((TransactionEventException) e).getTransactionEvent();
				if (te != null) {
					throw new AssertionError(
							format("Transaction with txid %s failed. %s", te.getTransactionID(), e.getMessage()), e);
				}
			}

			throw new AssertionError(format("Test failed with %s exception %s", e.getClass().getName(), e.getMessage()),
					e);

		}).get(testConfig.getTransactionWaitTime(), TimeUnit.SECONDS);
	}

	public static void instantiateChaincodeNode(Channel testChannel)
			throws InvalidArgumentException, ProposalException, ChaincodeEndorsementPolicyParseException, IOException,
			InterruptedException, ExecutionException, TimeoutException {
		InstantiateProposalRequest instantiateProposalRequest = hfclient.newInstantiationProposalRequest();
		instantiateProposalRequest.setChaincodeName(NODE_CHAIN_CODE_NAME);
		// instantiateProposalRequest.setChaincodePath("github.com/example_cc");
		instantiateProposalRequest.setArgs("A", "100", "B", "200");
		instantiateProposalRequest.setChaincodeLanguage(Type.NODE);
		instantiateProposalRequest.setChaincodeVersion(CHAIN_CODE_VERSION);
		Map<String, byte[]> tm = new HashMap<>();
		tm.put("HyperLedgerFabric", "InstantiateProposalRequest:NodeSDK".getBytes(UTF_8));
		tm.put("method", "InstantiateProposalRequest".getBytes(UTF_8));
		instantiateProposalRequest.setTransientMap(tm);
		instantiateProposalRequest.setProposalWaitTime(TestConfig.getConfig().getProposalWaitTime());
		instantiateProposalRequest.setTransientMap(tm);
		ChaincodeEndorsementPolicy chaincodeEndorsementPolicy = new ChaincodeEndorsementPolicy();
		chaincodeEndorsementPolicy
				.fromYamlFile(new File(TEST_FIXTURES_PATH + "/sdkintegration/chaincodeendorsementpolicy.yaml"));
		instantiateProposalRequest.setChaincodeEndorsementPolicy(chaincodeEndorsementPolicy);
		Collection<ProposalResponse> proposalResponse = testChannel
				.sendInstantiationProposal(instantiateProposalRequest);

		Iterator<ProposalResponse> iterator = proposalResponse.iterator();

		while (iterator.hasNext()) {
			ProposalResponse proposalResponse2 = iterator.next();
			System.out.println(new String(proposalResponse2.getPayloadBytes().toByteArray()));
			System.out.println(proposalResponse2.getMessage());
			System.out.println(proposalResponse2.getChaincodeID());
			System.out.println(proposalResponse2.getPayloadBytes());

		}

		TestConfig testConfig = TestConfig.getConfig();

		testChannel.sendTransaction(proposalResponse, hfclient.getUserContext()).thenApply(transactionEvent -> {
			try {

				assertTrue(transactionEvent.isValid()); // must be valid to be
														// here.
				System.out
						.println("Finished transaction with transaction id %s " + transactionEvent.getTransactionID());
				String testTxID = transactionEvent.getTransactionID(); // used
																		// in
																		// the
				// channel
				// queries later

				////////////////////////////
				// Send Query Proposal to all peers
				//
				int delta = 30;
				String expect = "" + (300 + delta);
				System.out.println("Now query chaincode for the value of b.");
				QueryByChaincodeRequest queryByChaincodeRequest = hfclient.newQueryProposalRequest();
				queryByChaincodeRequest.setArgs(new String[] { "b" });
				queryByChaincodeRequest.setFcn("query");
				ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName(NODE_CHAIN_CODE_NAME).build();
				queryByChaincodeRequest.setChaincodeID(chaincodeID);

				Map<String, byte[]> tm2 = new HashMap<>();
				tm2.put("HyperLedgerFabric", "QueryByChaincodeRequest:NodeSDK".getBytes(UTF_8));
				tm2.put("method", "QueryByChaincodeRequest".getBytes(UTF_8));
				queryByChaincodeRequest.setTransientMap(tm2);

				Collection<ProposalResponse> queryProposals = testChannel.queryByChaincode(queryByChaincodeRequest);
				for (ProposalResponse proposalResponse2 : queryProposals) {
					if (!proposalResponse2.isVerified()
							|| proposalResponse2.getStatus() != ProposalResponse.Status.SUCCESS) {
						fail("Failed query proposal from peer " + proposalResponse2.getPeer().getName() + " status: "
								+ proposalResponse2.getStatus() + ". Messages: " + proposalResponse2.getMessage()
								+ ". Was verified : " + proposalResponse2.isVerified());
					} else {
						String payload = proposalResponse2.getProposalResponse().getResponse().getPayload()
								.toStringUtf8();
						System.out.println(
								"Query payload of b from peer %s returned  " + proposalResponse2.getPeer().getName());
						// assertEquals(payload, expect);
					}
				}

				return null;
			} catch (Exception e) {
				System.err.println("Caught exception while running query");
				e.printStackTrace();
				fail("Failed during chaincode query with error : " + e.getMessage());
			}

			return null;
		}).exceptionally(e -> {
			if (e instanceof TransactionEventException) {
				BlockEvent.TransactionEvent te = ((TransactionEventException) e).getTransactionEvent();
				if (te != null) {
					throw new AssertionError(
							format("Transaction with txid %s failed. %s", te.getTransactionID(), e.getMessage()), e);
				}
			}

			throw new AssertionError(format("Test failed with %s exception %s", e.getClass().getName(), e.getMessage()),
					e);

		}).get(testConfig.getTransactionWaitTime(), TimeUnit.SECONDS);
	}

	public static void changeCarOwner(Channel testChannel, String... args)
			throws ProposalException, InvalidArgumentException {
		TransactionProposalRequest transactionProposalRequest = hfclient.newTransactionProposalRequest();
		;

		transactionProposalRequest.setFcn("changeCarOwner");

		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName("fabcar").build();

		transactionProposalRequest.setChaincodeID(chaincodeID);

		transactionProposalRequest.setArgs(args);
		// transactionProposalRequest.setArgs("CAR11", "Chevy1", "Volt1",
		// "Red1", "Nick1");

		Collection<ProposalResponse> proposalResponses = testChannel
				.sendTransactionProposal(transactionProposalRequest);

		testChannel.sendTransaction(proposalResponses, hfclient.getUserContext());
	}
	public static CompletableFuture<BlockEvent.TransactionEvent> genUPCC(Channel testChannel, String... args) 
			throws ProposalException, InvalidArgumentException {
		TransactionProposalRequest transactionProposalRequest = hfclient.newTransactionProposalRequest();
		;

		transactionProposalRequest.setFcn("initCommonLedger");

		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName(CHAIN_CODE_NAME).setVersion(CHAIN_CODE_VERSION).build();

		transactionProposalRequest.setChaincodeID(chaincodeID);

		transactionProposalRequest.setArgs(args);
		// transactionProposalRequest.setArgs("CAR11", "Chevy1", "Volt1",
		// "Red1", "Nick1");
		Collection<ProposalResponse> proposalResponses = testChannel
				.sendTransactionProposal(transactionProposalRequest);

		return testChannel.sendTransaction(proposalResponses, hfclient.getUserContext());
		

	}
	public static void portNo(Channel testChannel, String... args)
			throws ProposalException, InvalidArgumentException {
		TransactionProposalRequest transactionProposalRequest = hfclient.newTransactionProposalRequest();

		transactionProposalRequest.setFcn("portNo");

		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName(CHAIN_CODE_NAME).setVersion(CHAIN_CODE_VERSION).build();
		

		transactionProposalRequest.setChaincodeID(chaincodeID);

		transactionProposalRequest.setArgs(args);
		// transactionProposalRequest.setArgs("CAR11", "Chevy1", "Volt1",
		// "Red1", "Nick1");

		Collection<ProposalResponse> proposalResponses = testChannel
				.sendTransactionProposal(transactionProposalRequest);

		testChannel.sendTransaction(proposalResponses, hfclient.getUserContext());
	}
	public static void getHistoryForNumber(Channel testChannel, String... args)
			throws ProposalException, InvalidArgumentException {
		TransactionProposalRequest transactionProposalRequest = hfclient.newTransactionProposalRequest();

		transactionProposalRequest.setFcn("getAllTransactionForNumber");

		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName(CHAIN_CODE_NAME).setVersion(CHAIN_CODE_VERSION).build();
		

		transactionProposalRequest.setChaincodeID(chaincodeID);

		transactionProposalRequest.setArgs(args);
		// transactionProposalRequest.setArgs("CAR11", "Chevy1", "Volt1",
		// "Red1", "Nick1");

		Collection<ProposalResponse> proposalResponses = testChannel
				.sendTransactionProposal(transactionProposalRequest);

		testChannel.sendTransaction(proposalResponses, hfclient.getUserContext());
	}
	
	public static void createcar(Channel testChannel, String... args)
			throws ProposalException, InvalidArgumentException {
		TransactionProposalRequest transactionProposalRequest = hfclient.newTransactionProposalRequest();
		;

		transactionProposalRequest.setFcn("createCar");

		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName("fabcar").build();

		transactionProposalRequest.setChaincodeID(chaincodeID);

		transactionProposalRequest.setArgs(args);
		// transactionProposalRequest.setArgs("CAR11", "Chevy1", "Volt1",
		// "Red1", "Nick1");

		Collection<ProposalResponse> proposalResponses = testChannel
				.sendTransactionProposal(transactionProposalRequest);

		testChannel.sendTransaction(proposalResponses, hfclient.getUserContext());
	}

	public static QueryByChaincodeRequest queryAllcars() {
		QueryByChaincodeRequest queryByChaincodeRequest = QueryByChaincodeRequest
				.newInstance(hfclient.getUserContext());
		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName("fabcar").build();
		queryByChaincodeRequest.setChaincodeID(chaincodeID);
		queryByChaincodeRequest.setFcn("queryAllCars");
		return queryByChaincodeRequest;
	}

	public static QueryByChaincodeRequest queryOnecar(String carname) {
		QueryByChaincodeRequest queryByChaincodeRequest = QueryByChaincodeRequest
				.newInstance(hfclient.getUserContext());
		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName("fabcar").build();
		queryByChaincodeRequest.setChaincodeID(chaincodeID);
		queryByChaincodeRequest.setFcn("queryCar");
		queryByChaincodeRequest.setArgs(carname);
		return queryByChaincodeRequest;
	}
	public static QueryByChaincodeRequest queryOp(String number) {
		QueryByChaincodeRequest queryByChaincodeRequest = QueryByChaincodeRequest
				.newInstance(hfclient.getUserContext());
		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName(CHAIN_CODE_NAME).build();
		queryByChaincodeRequest.setChaincodeID(chaincodeID);
		queryByChaincodeRequest.setFcn("getOP");
		queryByChaincodeRequest.setArgs(number);
		return queryByChaincodeRequest;
	}
	static File findFileSk(String directorys) {

		File directory = new File(directorys);

		File[] matches = directory.listFiles((dir, name) -> name.endsWith("_sk"));

		if (null == matches) {
			throw new RuntimeException(
					format("Matches returned null does %s directory exist?", directory.getAbsoluteFile().getName()));
		}

		if (matches.length != 1) {
			throw new RuntimeException(format("Expected in %s only 1 sk file but found %d",
					directory.getAbsoluteFile().getName(), matches.length));
		}

		return matches[0];

	}
	
	public static void upgradeChaincodeNode(Channel testChannel)
			throws InvalidArgumentException, ProposalException, ChaincodeEndorsementPolicyParseException, IOException,
			InterruptedException, ExecutionException, TimeoutException {
		
		UpgradeProposalRequest upgradeProposalRequest = hfclient.newUpgradeProposalRequest();
		upgradeProposalRequest.setChaincodeName(CHAIN_CODE_NAME);
		upgradeProposalRequest.setChaincodePath("github.com/mnp");
		upgradeProposalRequest.setArgs("");
		upgradeProposalRequest.setChaincodeLanguage(Type.GO_LANG);
		upgradeProposalRequest.setChaincodeVersion(CHAIN_CODE_VERSION);
		Map<String, byte[]> tm = new HashMap<>();
		tm.put("HyperLedgerFabric", "UpgradeProposalRequest:JavaSDK".getBytes(UTF_8));
		tm.put("method", "UpgradeProposalRequest".getBytes(UTF_8));
		upgradeProposalRequest.setTransientMap(tm);
		upgradeProposalRequest.setProposalWaitTime(TestConfig.getConfig().getProposalWaitTime());
		upgradeProposalRequest.setTransientMap(tm);
		ChaincodeEndorsementPolicy chaincodeEndorsementPolicy = new ChaincodeEndorsementPolicy();
		chaincodeEndorsementPolicy
				.fromYamlFile(new File(TEST_FIXTURES_PATH + "/sdkintegration/chaincodeendorsementpolicy.yaml"));
		upgradeProposalRequest.setChaincodeEndorsementPolicy(chaincodeEndorsementPolicy);
		Collection<ProposalResponse> proposalResponse = testChannel
				.sendUpgradeProposal(upgradeProposalRequest);

		Iterator<ProposalResponse> iterator = proposalResponse.iterator();

		while (iterator.hasNext()) {
			ProposalResponse proposalResponse2 = iterator.next();
			System.out.println(new String(proposalResponse2.getPayloadBytes().toByteArray()));
			System.out.println(proposalResponse2.getMessage());
			System.out.println(proposalResponse2.getChaincodeID());
			System.out.println(proposalResponse2.getPayloadBytes());

		}

		
	}
}
