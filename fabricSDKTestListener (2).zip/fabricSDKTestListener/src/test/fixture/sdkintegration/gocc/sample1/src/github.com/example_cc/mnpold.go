/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

/*
 * The sample smart contract for documentation topic:
 * Writing Your First Blockchain Application
 */

package main

/* Imports
 * 4 utility libraries for formatting, handling bytes, reading and writing JSON, and string manipulation
 * 2 specific Hyperledger Fabric specific libraries for Smart Contracts
 */
import (
	"encoding/json"
	"fmt"
	"strconv"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	sc "github.com/hyperledger/fabric/protos/peer"
)

// Define the Smart Contract structure
type SmartContract struct {
}

// Define the car structure, with 4 properties.  Structure tags are used by encoding/json library
type Userdata struct {
	Operator   string `json:"operator"`
	Upcc  string `json:"upcc"`
}

/*
 * The Init method is called when the Smart Contract "mnpdata" is instantiated by the blockchain network
 * Best practice is to have any Ledger initialization in separate function -- see initLedger()
 */
func (s *SmartContract) Init(APIstub shim.ChaincodeStubInterface) sc.Response {
	users := []Userdata{
		Userdata{Operator: "Idea"},
		Userdata{Operator: "Jio"},
	}

	i := 0
	for i < len(users) {
		fmt.Println("i is ", i)
		mnpAsBytes, _ := json.Marshal(users[i])
		APIstub.PutState("998757145"+strconv.Itoa(i), mnpAsBytes)
		fmt.Println("Added", users[i])
		i = i + 1
	}
	return shim.Success(nil)
}

/*
 * The Invoke method is called as a result of an application request to run the Smart Contract "fabcar"
 * The calling application program has also specified the particular smart contract function to be called, with arguments
 */
func (s *SmartContract) Invoke(APIstub shim.ChaincodeStubInterface) sc.Response {

	// Retrieve the requested Smart Contract function and arguments
	function, args := APIstub.GetFunctionAndParameters()
	// Route to the appropriate handler function to interact with the ledger appropriately
	if function == "initLedger" {
		return s.initLedger(APIstub)
	} else if function == "genUPCC" {
		return s.genUPCC(APIstub, args)
	} else if function == "portNo" {
		return s.portNo(APIstub, args)
	} else if function == "getOP" {
		return s.getOP(APIstub, args)
	} else if function == "recordUPCgeneration" {
		return s.recordUPCgeneration(APIstub, args)
	} else if function == "getUPCRecord" {
		return s.getUPCRecord(APIstub, args)
	}

	return shim.Error("Invalid Smart Contract function name.")
}


func (s *SmartContract) initLedger(APIstub shim.ChaincodeStubInterface) sc.Response {
	users := []Userdata{
		Userdata{Operator: "Airtel"},
		Userdata{Operator: "Jio"},
	}

	i := 0
	for i < len(users) {
		fmt.Println("i is ", i)
		mnpAsBytes, _ := json.Marshal(users[i])
		APIstub.PutState("998757145"+strconv.Itoa(i), mnpAsBytes)
		fmt.Println("Added", users[i])
		i = i + 1
	}

	return shim.Success(nil)
}

/*
 *This method is for recordUPCGeneration in mnp poc
 */
func (s *SmartContract) recordUPCgeneration(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {
  
  if len(args) < 2  {
    return shim.Error("Incorrect number of arguments. Expecting 2")
  }
  mobileNumber := args[0]
  payload := args[1]
  fmt.Println("new Payload is " + payload)
  //to do validation if any in future
  APIstub.PutState(mobileNumber, []byte(payload))
  return shim.Success([]byte("Succsesully recored UPCC genetaion fro number"+mobileNumber))
}

/*
 *This method get the upc record for a number
 */ 	
func (s *SmartContract) getUPCRecord(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {

	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments. Expecting 1")
	}

	mnpAsBytes, _ := APIstub.GetState(args[0])
    
    if(mnpAsBytes  == nil){
    	return shim.Error("No Record with this number")
    }

	return shim.Success(mnpAsBytes)
}



func (s *SmartContract) genUPCC(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {

	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments. Expecting 1")
	}

	mnpAsBytes, _ := APIstub.GetState(args[0])
	mnp := Userdata{}

	json.Unmarshal(mnpAsBytes, &mnp)
    mnp.Upcc = "12345"
	mnpAsBytes, _ = json.Marshal(mnp)
	APIstub.PutState(args[0], mnpAsBytes)

	return shim.Success([]byte(strconv.Itoa(12345)))
}

func (s *SmartContract) getOP(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {

	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments. Expecting 1")
	}

	mnpAsBytes, _ := APIstub.GetState(args[0])
	mnp := Userdata{}

	json.Unmarshal(mnpAsBytes, &mnp)
	return shim.Success([]byte(mnp.Operator))
}
func (s *SmartContract) portNo(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {

	if len(args) != 3 {
		return shim.Error("Incorrect number of arguments. Expecting 3")
	}

	mnpAsBytes, _ := APIstub.GetState(args[0])
	mnp := Userdata{}

	json.Unmarshal(mnpAsBytes, &mnp)
    if mnp.Upcc == args[1] {
	mnpAsBytes, _ = json.Marshal(mnp)
	mnp.Operator = args[2]
	APIstub.PutState(args[0], mnpAsBytes)

	return shim.Success([]byte(strconv.Itoa(12345)))
    }
    return shim.Error("Invalid UPCC code")
}


// The main function is only relevant in unit test mode. Only included here for completeness.
func main() {

	// Create a new Smart Contract
	err := shim.Start(new(SmartContract))
	if err != nil {
		fmt.Printf("Error creating new Smart Contract: %s", err)
	}
}
