/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

/*
 * The sample smart contract for documentation topic:
 * Writing Your First Blockchain Application
 */

package main

/* Imports
 * 4 utility libraries for formatting, handling bytes, reading and writing JSON, and string manipulation
 * 2 specific Hyperledger Fabric specific libraries for Smart Contracts
 */
import (
  "encoding/json"
  "fmt"
  "strconv"

  "github.com/hyperledger/fabric/core/chaincode/shim"
  sc "github.com/hyperledger/fabric/protos/peer"
  "time"
  "bytes"
)

// Define the Smart Contract structure
type SmartContract struct {
}

// Define the car structure, with 4 properties.  Structure tags are used by encoding/json library
type Userdata struct {
  Operator   string `json:"operator"`
  Upcc  string `json:"upcc"`
}

/*
 * The Init method is called when the Smart Contract "mnpdata" is instantiated by the blockchain network
 * Best practice is to have any Ledger initialization in separate function -- see initLedger()
 */
func (s *SmartContract) Init(APIstub shim.ChaincodeStubInterface) sc.Response {
 
  return shim.Success(nil)
}

/*
 * The Invoke method is called as a result of an application request to run the Smart Contract "fabcar"
 * The calling application program has also specified the particular smart contract function to be called, with arguments
 */
func (s *SmartContract) Invoke(APIstub shim.ChaincodeStubInterface) sc.Response {

  // Retrieve the requested Smart Contract function and arguments
  function, args := APIstub.GetFunctionAndParameters()
  // Route to the appropriate handler function to interact with the ledger appropriately
  if function == "initCommonLedger" {
    return s.initCommonLedger(APIstub)
  } else if function == "initPairLedger" {
    return s.initPairLedger(APIstub)
  } else if function == "recordUPCgeneration" {
    return s.recordUPCgeneration(APIstub, args)
  } else if function == "getUPCRecord" {
    return s.getUPCRecord(APIstub, args)
  } else if function == "getMNPStatus" {
    return s.getMNPStatus(APIstub, args)
  }	else if function == "validateUPC" {
    return s.validateUPC(APIstub, args)
  } else if function == "validateEligibility" {
  	return s.validateEligibility(APIstub, args)
  } else if function == "getSubscriberInfofromDO" {
  	return s.getSubscriberInfofromDO(APIstub, args)
  } else if function == "getSubscriberInfofromCommonChannel" {
  	return s.getSubscriberInfofromCommonChannel(APIstub, args)
  } else if function == "processeKYCwithRO" {
  	return s.processeKYCwithRO(APIstub, args)
  } else if function == "recordPortOutRequest" {
  	return s.recordPortOutRequest(APIstub, args)
  } else if function == "insertMNPTransaction" {
  	return s.insertMNPTransaction(APIstub, args)
  } else if function == "updateDocument" {
  	return s.updateDocument(APIstub, args)
  } else if function == "appendDocument" {
  	return s.appendDocument(APIstub, args)
  }	else if function == "getAllTransactionForNumber" {
  	return s.getAllTransactionForNumber(APIstub, args)
  }	
  return shim.Error("Invalid Smart Contract function name.")
}

/*
 *This method is for creating prepopulted data in common channel
 */
func (s *SmartContract) initCommonLedger(APIstub shim.ChaincodeStubInterface) sc.Response {
  
  demo1 := "{\"mobile_no\":\"7724005281\",\"subscriber_UUID\":\"127187261926\",\"Current_Operator\":\"Airtel\",\"Plan\":\"Prepaid\",\"LastMNP\":\"01/01/2017\"}"
  APIstub.PutState("7724005281", []byte(demo1))
  demo2 := "{\"mobile_no\":\"7724005282\",\"subscriber_UUID\":\"127187261927\",\"Current_Operator\":\"Airtel\",\"Plan\":\"Prepaid\",\"LastMNP\":\"01/01/2017\"}"
  APIstub.PutState("7724005282", []byte(demo2))
  return shim.Success(nil)
}

/*
 *This method is for creating prepopulted data in common channel
 */
func (s *SmartContract) insertMNPTransaction(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {
  
  APIstub.PutState(args[0], []byte(args[1]))
    return shim.Success(nil)
}

/*
 *This method is for creating prepopulted data for subscriber in RO mch channel
 */
func (s *SmartContract) initPairLedger(APIstub shim.ChaincodeStubInterface) sc.Response {
  
  demop := "{\"Customer_Segment\":\"Prepaid\",\"eKYC_Status\":\"Completed\",\"Contractual_Obligation\":\"No\",\"Corporate_connection\":\"No\",\"Network_Ageing\":\"270\",\"Under_Processing\":\"No\",\"Payments_Due\":\"0\",\"Sub_judice\":\"No\",\"Prohibited\":\"No\",\"LEA_flag\":\"No\",\"Aadhar_Number\":\"897654321012\"}"
 
  APIstub.PutState("7724005282", []byte(demop))
   APIstub.PutState("7724005281", []byte(demop))
  return shim.Success(nil)
}

/*
 *This method is for recordUPCGeneration in mnp poc
 */
func (s *SmartContract) recordUPCgeneration(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {
  
  if len(args) < 2  {
    return shim.Error("Incorrect number of arguments. Expecting 2")
  }
  mobileNumber := args[0]
  payload := args[1]
  fmt.Println("new Payload is " + payload)
  //to do validation if any in future
  APIstub.PutState(mobileNumber, []byte(payload))
  return shim.Success([]byte("Succsesully recored UPCC genetaion fro number"+mobileNumber))
}

/*
 *This method get the upc record for a number
 */   
func (s *SmartContract) getUPCRecord(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {

  if len(args) != 1 {
    return shim.Error("Incorrect number of arguments. Expecting 1")
  }

  mnpAsBytes, _ := APIstub.GetState(args[0])
    
    if(mnpAsBytes  == nil){
      return shim.Error("No Record with this number")
    }

  return shim.Success(mnpAsBytes)
}

/*
 *This method get the upc record for a number
 */   
func (s *SmartContract) getMNPStatus(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {

  if len(args) != 1 {
    return shim.Error("Incorrect number of arguments. Expecting 1")
  }

  mnpAsBytes, _ := APIstub.GetState(args[0])
    
    if(mnpAsBytes  == nil){
      return shim.Error("No Record with this number")
    }

  return shim.Success(mnpAsBytes)
}

/*
 *This method validates the upc code on a channel
 */   
func (s *SmartContract) validateUPC(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {

  if len(args) < 2 {
    return shim.Error("Incorrect number of arguments. Expecting 2")
  }
	  var upcRecord map[string]string	 
	  mnpAsBytes, _ := APIstub.GetState(args[0])
	   if(mnpAsBytes  == nil){
      return shim.Error("No Record with this number")
    }
	  json.Unmarshal(mnpAsBytes, &upcRecord)
	  if upcRecord["UPC_Code"] == args[1] {
	  	 return shim.Success([]byte("Correct UPC"))
	  } else{
	   	return shim.Error("Incorrect UPC")
	   }
}

/*
 *This method validates the eligibility for mnp
 */   
func (s *SmartContract) validateEligibility(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {
 
  if len(args) < 2 {
    return shim.Error("Incorrect number of arguments. Expecting 2")
  }
	  var upcRecord map[string]string	 
	  mnpAsBytes, _ := APIstub.GetState(args[0])
	   if(mnpAsBytes  == nil){
      return shim.Error("No Record with this number")
    }
	  json.Unmarshal(mnpAsBytes, &upcRecord)
	  age,_:= strconv.Atoi(upcRecord["Network_Ageing"])
	  if age >= 90 {
      	payment,_:=strconv.Atoi(upcRecord["Payments_Due"])
        if payment == 0 { 
      	  if upcRecord["Sub_judice"] == "No" {
      	  	if upcRecord["Prohibited"] == "No"{
      	  		return shim.Success([]byte("Eligible"))
      	  	}
      	  }
        }
         return shim.Success([]byte("Eligible"))
      } else{
	   	return shim.Success([]byte("Not Eligible"))
	   }
}

/*
 *This method fetched the subsciber info from DO
 */   
func (s *SmartContract) getSubscriberInfofromDO(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {

	 if len(args) != 1 {
	    return shim.Error("Incorrect number of arguments. Expecting 1")
	  }

	  mnpAsBytes, _ := APIstub.GetState(args[0])
    
    if(mnpAsBytes  == nil){
      return shim.Error("No Record with this number")
    }

	  return shim.Success(mnpAsBytes)
}

/*
 *This method fetched the subsciber info from DO
 */   
func (s *SmartContract) getSubscriberInfofromCommonChannel(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {

	 if len(args) != 1 {
	    return shim.Error("Incorrect number of arguments. Expecting 1")
	  }

	  mnpAsBytes, _ := APIstub.GetState(args[0])
    
    if(mnpAsBytes  == nil){
      return shim.Error("No Record with this number")
    }

	  return shim.Success(mnpAsBytes)
}

/*
 *This method will processe the KYC with RO
 */   
func (s *SmartContract) processeKYCwithRO(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {

  if len(args) != 1 {
    return shim.Error("Incorrect number of arguments. Expecting 1")
  }

		var upcRecord map[string]string	 
	  mnpAsBytes, _ := APIstub.GetState(args[0])
	   if(mnpAsBytes  == nil){
      return shim.Error("No Record with this number")
    }
	  json.Unmarshal(mnpAsBytes, &upcRecord)
	  upcRecord["eKYC_Status"] = "Completed"
	  mapData, _ := json.Marshal(upcRecord) 
	 fmt.Println("new Payload is " + string(mapData))
	  //to do validation if any in future
	  APIstub.PutState(args[0], mapData)
	 return shim.Success([]byte("KYC processed"))
	  
}

/*
 *This method will record the port out request
 */   
func (s *SmartContract) recordPortOutRequest(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {

  if len(args) != 1 {
    return shim.Error("Incorrect number of arguments. Expecting 1")
  }

		var upcRecord map[string]string	 
	  mnpAsBytes, _ := APIstub.GetState(args[0])
	   if(mnpAsBytes  == nil){
      return shim.Error("No Record with this number")
    }
	  json.Unmarshal(mnpAsBytes, &upcRecord)
	  if upcRecord["eKYC_Status"] == "Completed" {
	  
	   upcRecord["MNP_Eligibility"] = "Completed"
	   upcRecord["MNP_State"] = "Initiated"
	  }
	  
	  mapData, _ := json.Marshal(upcRecord) 
	fmt.Println("new Payload is " + string(mapData))
	  //to do validation if any in future
	  APIstub.PutState(args[0], mapData)
	 return shim.Success([]byte("Port out request initiated"))
	  
}

/*
 *This method will update the key with newer value inside a json
 */   
func (s *SmartContract) updateDocument(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {

	  if len(args) <= 1 {
	    return shim.Error("Incorrect number of arguments. Expecting 2 args")
	   }
      var existingRecMap map[string]string
	  var updatedFields map[string]string
		
	  mnpAsBytes, _ := APIstub.GetState(args[0])
	   if(mnpAsBytes  == nil){
      return shim.Error("No Record with this number")
	    }
	  json.Unmarshal(mnpAsBytes, &existingRecMap)
	  payload := args[1]
	  json.Unmarshal([]byte(payload), &updatedFields)
	  updatedRecord, _ := updateRecord(existingRecMap, updatedFields)
	  APIstub.PutState(args[0], []byte(updatedRecord))
	  return shim.Success([]byte("Succesfully updated"))
}

/*
 *This method will update the key with newer value inside a json
 */   
func (s *SmartContract) appendDocument(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {

	  if len(args) <= 1 {
	    return shim.Error("Incorrect number of arguments. Expecting 2 args")
	   }
      var existingRecMap map[string]string
	  var appendFields map[string]string
		
	  mnpAsBytes, _ := APIstub.GetState(args[0])
	   if(mnpAsBytes  == nil){
      return shim.Error("No Record with this number")
	    }
	  json.Unmarshal(mnpAsBytes, &existingRecMap)
	   fmt.Println(args[1])
	  payload := args[1]
	  json.Unmarshal([]byte(payload), &appendFields)
	  fmt.Println(appendFields)
	  for key, value := range appendFields {
					
					fmt.Println("new key is " + key)
						fmt.Println("new value is " + value)
					existingRecMap[key] = value
				}	  
	  mapData, _ := json.Marshal(existingRecMap) 
	  fmt.Println("new Payload is " + string(mapData))
	  //to do validation if any in future
	  APIstub.PutState(args[0], mapData)
	  return shim.Success([]byte("Success"))
}



//Update the existing record with the mofied key value pair
func updateRecord(existingRecord map[string]string, fieldsToUpdate map[string]string) (string, error) {
	for key, value := range fieldsToUpdate {

		existingRecord[key] = value
	}
	outputMapBytes, _ := json.Marshal(existingRecord)
	fmt.Printf("updateRecord: Final json after update " + string(outputMapBytes))
	return string(outputMapBytes), nil
}


//get the history for a number
func (s *SmartContract) getAllTransactionForNumber(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {
	fmt.Println("getAllTransactionForNumber called")
	mobileNum := args[0]

	fmt.Printf("- start getAllTransactionForNumber: %s\n", mobileNum)

	resultsIterator, err := APIstub.GetHistoryForKey(mobileNum)
	if err != nil {
		return shim.Error(err.Error())
	}
	defer resultsIterator.Close()

	// buffer is a JSON array containing historic values for the number
	var buffer bytes.Buffer
	buffer.WriteString("[")

	bArrayMemberAlreadyWritten := false
	for resultsIterator.HasNext() {
		response, err := resultsIterator.Next()
		if err != nil {
			return shim.Error(err.Error())
		}
		// Add a comma before array members, suppress it for the first array member
		if bArrayMemberAlreadyWritten == true {
			buffer.WriteString(",")
		}
		buffer.WriteString("{\"TxId\":")
		buffer.WriteString("\"")
		buffer.WriteString(response.TxId)
		buffer.WriteString("\"")

		buffer.WriteString(", \"Value\":")
		// if it was a delete operation on given key, then we need to set the
		//corresponding value null. Else, we will write the response.Value
		//as-is (as the Value itself a JSON marble)
		if response.IsDelete {
			buffer.WriteString("null")
		} else {
			buffer.WriteString(string(response.Value))
		}

		buffer.WriteString(", \"Timestamp\":")
		buffer.WriteString("\"")
		buffer.WriteString(time.Unix(response.Timestamp.Seconds, int64(response.Timestamp.Nanos)).String())
		buffer.WriteString("\"")

		buffer.WriteString(", \"IsDelete\":")
		buffer.WriteString("\"")
		buffer.WriteString(strconv.FormatBool(response.IsDelete))
		buffer.WriteString("\"")

		buffer.WriteString("}")
		bArrayMemberAlreadyWritten = true
	}
	buffer.WriteString("]")

	fmt.Printf("- getHistoryForMarble returning:\n%s\n", buffer.String())

	return shim.Success(buffer.Bytes())
}




// The main function is only relevant in unit test mode. Only included here for completeness.
func main() {

  // Create a new Smart Contract
  err := shim.Start(new(SmartContract))
  if err != nil {
    fmt.Printf("Error creating new Smart Contract: %s", err)
  }
}