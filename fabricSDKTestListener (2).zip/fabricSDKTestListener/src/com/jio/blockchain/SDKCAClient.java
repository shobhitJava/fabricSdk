package com.jio.blockchain;

import static java.lang.String.format;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.lang.reflect.InvocationTargetException;
import java.net.MalformedURLException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.spec.InvalidKeySpecException;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.SimpleLayout;
import org.bouncycastle.openssl.PEMWriter;
import org.hyperledger.fabric.sdk.Enrollment;
import org.hyperledger.fabric.sdk.HFClient;
import org.hyperledger.fabric.sdk.exception.CryptoException;
import org.hyperledger.fabric.sdk.exception.InvalidArgumentException;
import org.hyperledger.fabric.sdk.security.CryptoSuite;
import org.hyperledger.fabric.sdkintegration.SampleUser;
import org.hyperledger.fabric_ca.sdk.EnrollmentRequest;
import org.hyperledger.fabric_ca.sdk.HFCAClient;
import org.hyperledger.fabric_ca.sdk.HFCAInfo;
import org.hyperledger.fabric_ca.sdk.RegistrationRequest;
import org.hyperledger.fabric_ca.sdk.RegistrationRequestTest;
import org.hyperledger.fabric_ca.sdk.exception.EnrollmentException;
import org.hyperledger.fabric_ca.sdk.exception.RegistrationException;

import com.sun.org.apache.bcel.internal.classfile.Attribute;

public class SDKCAClient {
	private static final String orgName = "jiomnp.com";
	private static final String USER_MSP_ID = "jiomnpMSP";
	//private static final String keystoreLocation = "C:\\BlockchainCerti";
	private static final String usercertfile = "C:\\BlockchainCerti\\Admin@jiomnp.com-cert.pem";
	private static final String keystoreLocation = "C:\\BlockchainCerti";
	//private static final String usercertfile = "C:\\BlockchainCerti\\newpem";
	
	
	private static final String regCAName = "CA";
	private static final String regID = "shobhit";
	private static final String regSecret = "adminpw";
	private static final String regType = "user";
	private static final int regMaxEnrollments = 5;
	private static final String regAffiliation = "jiomnp.com";

	// private static final String usercertfile =
	// "C:\\Users\\vikash.agrawal\\Desktop\\hfc-key-store\\admin1\\Admin@org1.example.com-cert.";
	// private static final String usercertfile =
	// "C:\\Users\\vikash.agrawal\\Desktop\\mnp\\user1\\signcerts\\User1@user.mnp1.com-cert.pem";
	// private static final String usercertfile =
	// "C:\\Users\\vikash.agrawal\\Desktop\\mnp\\user1\\signcerts\\User1@org1.example.com-cert.pem";
	
	public static void main(String[] args) {
		try {
			Logger logger = Logger.getLogger(SDKClient.class);
			logger.getRoot().addAppender(new ConsoleAppender(new SimpleLayout()));
			logger.setLevel(Level.DEBUG);
			System.out.println("creating hf CA client");
	
			
			HFCAClient memberServices = HFCAClient.createNewInstance("http://10.64.217.120:7054", null);
			 
		/*	
			// SampleUser can be any implementation that implements
			// org.hyperledger.fabric.sdk.User Interface
			File tempFile = File.createTempFile("teststore", "properties");

			tempFile.deleteOnExit();

			

			if (sampleStoreFile.exists()) { // For testing start fresh
				sampleStoreFile.delete();
			}
			logger.info("creating store object");
			final SDKStore sdkStore = new SDKStore(sampleStoreFile);
*/
			File sampleStoreFile = new File(System.getProperty("user.home") + "/test.properties");
			final SDKStore sdkStore = new SDKStore(sampleStoreFile);
			CryptoSuite cryptoSuite =CryptoSuite.Factory.getCryptoSuite();
		
			memberServices.setCryptoSuite(cryptoSuite);
			System.out.println(memberServices.getCAName());
			//Enrollment enrollment =memberServices.enroll("admin", "adminpw");

			
	//		EnrollmentRequest enrollmentRequest = new EnrollmentRequest();
			
			//enrollmentRequest.addHost("vikash:adminpw@10.64.217.120:7054");
			

			//memberServices.enroll("admin", "adminpw", enrollmentRequest);
		  //  final Enrollment enroll = ca.enroll("admin", "adminpw", enrollmentRequestTLS);
           // final String tlsCertPEM = enrollment.getCert();
           // final String tlsKeyPEM = getPEMStringFromPrivateKey(enrollment.getKey());
			 
			 
			/* SDKUser admin = sdkStore.getMember("admin", orgName, USER_MSP_ID, findFileSk(keystoreLocation),
						new File(usercertfile));
*/
		
			 
		/*	 SDKUser admin = sdkStore.getMember("admin", orgName, USER_MSP_ID, enrollment.getKey().,
						new File(usercertfile));*/
			// memberServices.newHFCAIdentity(regID).create(admin);
			 
			
	           
	               /* RegistrationRequest rr = new RegistrationRequest(regID, orgName);
	               
	                rr.setSecret( memberServices.register(rr, admin));
	                
	         */  
	               
	            
	          //  sampleOrg.addUser(user); //Remember user belongs to this Org

			SDKUser someTestUSER = sdkStore.getMember("admin", orgName, "jiomnpMSP",
					findFileSk(keystoreLocation), new File(usercertfile));
            
			 
			RegistrationRequest testRegisterReq = new RegistrationRequest(regID, orgName);
			testRegisterReq.setEnrollmentID(regID );
			testRegisterReq.setSecret(regSecret);
			//testRegisterReq.setMaxEnrollments(regMaxEnrollments);\
		    org.hyperledger.fabric_ca.sdk.Attribute attr = new org.hyperledger.fabric_ca.sdk.Attribute("hf.Registrar.Roles", "peer,user");
			testRegisterReq.addAttribute(attr);
			testRegisterReq.setType(regType);
			testRegisterReq.setAffiliation(orgName);
			//testRegisterReq.setCAName(regCAName);
			String enrollmentSecret= memberServices.register(testRegisterReq, someTestUSER);
			Enrollment enrollment =memberServices.enroll(regID, enrollmentSecret);
			
			final String tlsCertPEM = enrollment.getCert();
	           final String tlsKeyPEM = getPEMStringFromPrivateKey(enrollment.getKey());
			//memberServices.enroll(regID, enrollmentSecret);
			//SDKUser someTestUSER = sdkStore.getMember("admin", orgName, "jiomnpMSP",
					//findFileSk(keystoreLocation), new File(usercertfile));
			
			//someTestUSER.setMspId(USER_MSP_ID);
			//HFClient hfclient = HFClient.createNewInstance();
		//	hfclient.setUserContext(someTestUSER);
			//hfclient.setCryptoSuite(CryptoSuite.Factory.getCryptoSuite());
			
			
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CryptoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchProviderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidKeySpecException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (EnrollmentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (org.hyperledger.fabric_ca.sdk.exception.InvalidArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RegistrationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	static File findFileSk(String directorys) {

		File directory = new File(directorys);

		File[] matches = directory.listFiles((dir, name) -> name.endsWith("_sk"));

		if (null == matches) {
			throw new RuntimeException(
					format("Matches returned null does %s directory exist?", directory.getAbsoluteFile().getName()));
		}

		if (matches.length != 1) {
			throw new RuntimeException(format("Expected in %s only 1 sk file but found %d",
					directory.getAbsoluteFile().getName(), matches.length));
		}

		return matches[0];

	}
	 static String getPEMStringFromPrivateKey(PrivateKey privateKey) throws IOException {
	        StringWriter pemStrWriter = new StringWriter();
	        PEMWriter pemWriter = new PEMWriter(pemStrWriter);

	        pemWriter.writeObject(privateKey);

	        pemWriter.close();

	        return pemStrWriter.toString();
	    }
}
