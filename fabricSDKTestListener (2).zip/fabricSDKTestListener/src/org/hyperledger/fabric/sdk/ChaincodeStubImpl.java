package org.hyperledger.fabric.sdk;

import java.time.Instant;
import java.util.List;
import java.util.Map;

import org.hyperledger.fabric.protos.peer.ChaincodeEventPackage.ChaincodeEvent;
import org.hyperledger.fabric.protos.peer.ProposalPackage.SignedProposal;
import org.hyperledger.fabric.shim.Chaincode.Response;
import org.hyperledger.fabric.shim.ChaincodeStub;
import org.hyperledger.fabric.shim.ledger.CompositeKey;
import org.hyperledger.fabric.shim.ledger.KeyModification;
import org.hyperledger.fabric.shim.ledger.KeyValue;
import org.hyperledger.fabric.shim.ledger.QueryResultsIterator;

public class ChaincodeStubImpl implements ChaincodeStub{

	@Override
	public CompositeKey createCompositeKey(String arg0, String... arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delState(String arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<byte[]> getArgs() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public byte[] getBinding() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getChannelId() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public byte[] getCreator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ChaincodeEvent getEvent() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFunction() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public QueryResultsIterator<KeyModification> getHistoryForKey(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> getParameters() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public QueryResultsIterator<KeyValue> getQueryResult(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SignedProposal getSignedProposal() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public byte[] getState(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public QueryResultsIterator<KeyValue> getStateByPartialCompositeKey(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public QueryResultsIterator<KeyValue> getStateByRange(String arg0, String arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> getStringArgs() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<String, byte[]> getTransient() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getTxId() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Instant getTxTimestamp() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Response invokeChaincode(String arg0, List<byte[]> arg1, String arg2) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void putState(String arg0, byte[] arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setEvent(String arg0, byte[] arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public CompositeKey splitCompositeKey(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

}
