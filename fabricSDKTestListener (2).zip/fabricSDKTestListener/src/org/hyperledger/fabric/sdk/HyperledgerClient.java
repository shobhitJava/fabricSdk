package org.hyperledger.fabric.sdk;

import org.hyperledger.fabric_ca.sdk.HFCAClient;

public class HyperledgerClient {
public static void main(String[] args) {
	HFClient hfClient = HFClient.createNewInstance();
//	HFCAClient hfcaClient = HFCAClient.createNewInstance(url, properties);
	
	//hfClient.setUserContext(userContext);
}
}
