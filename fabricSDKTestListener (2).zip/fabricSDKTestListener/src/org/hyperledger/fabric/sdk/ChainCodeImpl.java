package org.hyperledger.fabric.sdk;

import org.hyperledger.fabric.shim.Chaincode;
import org.hyperledger.fabric.shim.Chaincode.Response.Status;
import org.hyperledger.fabric.shim.ChaincodeStub;

public class ChainCodeImpl implements Chaincode {

	@Override
	public Response init(ChaincodeStub stub) {
		// TODO Auto-generated method stub
		String[] args = (String[]) stub.getStringArgs().toArray();
		if (stub.getStringArgs().size() != 2)
			return new Response(Status.forCode(400), "Incorrect arguments. Expecting a key and a value", null);
		try {
			stub.putState(args[0], args[1].getBytes());
		} catch (Exception e) {
			return new Response(Status.forCode(500), "Failed to create asset:", null);
		}

		System.out.println("intialized successfully");
		return new Response(Status.SUCCESS, "success", null);
	}

	@Override
	public Response invoke(ChaincodeStub stub) {
		// TODO Auto-generated method stub
		String func = stub.getFunction();
		String[] params = (String[]) (stub.getParameters().toArray());
		switch (func) {

		case "get":
			stub.getState(params[0]);

			break;
		case "set":
			if (params.length != 2) {
				return new Response(Status.forCode(400), "Incorrect arguments. Expecting a key and a value", null);
			}
			stub.putState(params[0], params[1].getBytes());

			break;
		default:
			break;
		}
		System.out.println("invoked successfully");
		return null;
	}

	
}
