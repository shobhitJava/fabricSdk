package com.jio.blockchain;

import java.util.Scanner;

public class TestTech {

	
 public static void main(String args[]){
	 Scanner in = new Scanner(System.in);
		
		int b = in.nextInt();
		int r = in.nextInt();
		int y = in.nextInt();
		int g = in.nextInt();
		in.close();
		int ways = 0;
		int c = 0;
		if (b<=1 && r <=1 && y<=1&& g <=1){
		    ways=b+r+y+g;
		}
		else{
		    if(b>=1){
		        if(r>1){
		           
		        ways = b + 1 + g;
		        r = r -1;
		        
		        if(y >1){
		            c = c + 1;
		            y = y -1;
		        }
		       while(y>1 & r>1){
		        	ways =ways +2;
		        	y=y-1;
		        	r=r-1;
		        }

		        }
		        else{
		        ways = b;
		        }}else if(r >= 1){
		             if(g>1){
		               ways = 1 + g + 1 ;
		               r = r-1;
		               y = y -1;
		             }
		              while(y>1 & r>1){
		        	ways =ways +2;
		        	y=y-1;
		        	r=r-1;
		        }
		             
		         }
		        
		}
		System.out.println(ways);
	 
 }
	
}
