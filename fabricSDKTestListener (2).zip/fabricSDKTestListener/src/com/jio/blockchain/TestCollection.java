package com.jio.blockchain;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class TestCollection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		class Address {
			private int id;
			private String name;
			public int getId() {
				return id;
			}
			public void setId(int id) {
				this.id = id;
			}
			public String getName() {
				return name;
			}
			public void setName(String name) {
				this.name = name;
			}
			
			
		}
		class Student{
			private Address ad;
			private int number;
			public Address getAd() {
				return ad;
			}
			public void setAd(Address ad) {
				this.ad = ad;
			}
			public int getNumber() {
				return number;
			}
			public void setNumber(int number) {
				this.number = number;
			}
			
			
		}

		Map<Student, Address> list = new ConcurrentHashMap();
		Student st= new Student();
		st.setNumber(999087546);
		Address ad =new Address();
		ad.setId(1);
		ad.setName("Shobhit");
		st.setAd(ad);
		list.put(st, ad);
		st.ad.setId(89890);
		
		for (Map.Entry<Student, Address> entry : list.entrySet()) {
			System.out.println("Number : " + entry.getKey().getNumber() + " Id : " + entry.getValue().getId());
		}
		
		System.out.println(ad.getId());
	}

}
