/*
 *  Copyright 2016 DTCC, Fujitsu Australia Software Technology, IBM - All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package com.jio.blockchain;

import static java.lang.String.format;
import static java.nio.charset.StandardCharsets.UTF_8;
import static org.hyperledger.fabric.sdk.testutils.TestUtils.resetConfig;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.regex.Pattern;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.SimpleLayout;
import org.hyperledger.fabric.sdk.BlockEvent;
import org.hyperledger.fabric.sdk.ChaincodeEndorsementPolicy;
import org.hyperledger.fabric.sdk.ChaincodeID;
import org.hyperledger.fabric.sdk.Channel;
import org.hyperledger.fabric.sdk.HFClient;
import org.hyperledger.fabric.sdk.InstallProposalRequest;
import org.hyperledger.fabric.sdk.InstantiateProposalRequest;
import org.hyperledger.fabric.sdk.Orderer;
import org.hyperledger.fabric.sdk.Peer;
import org.hyperledger.fabric.sdk.ProposalResponse;
import org.hyperledger.fabric.sdk.QueryByChaincodeRequest;
import org.hyperledger.fabric.sdk.TestHFClient;
import org.hyperledger.fabric.sdk.TransactionProposalRequest;
import org.hyperledger.fabric.sdk.TransactionRequest.Type;
import org.hyperledger.fabric.sdk.exception.ChaincodeEndorsementPolicyParseException;
import org.hyperledger.fabric.sdk.exception.InvalidArgumentException;
import org.hyperledger.fabric.sdk.exception.ProposalException;
import org.hyperledger.fabric.sdk.exception.TransactionEventException;
import org.hyperledger.fabric.sdk.helper.Config;
import org.hyperledger.fabric.sdk.security.CryptoSuite;
import org.hyperledger.fabric.sdk.testutils.TestConfig;
import org.hyperledger.fabric.sdk.testutils.TestUtils;
import org.hyperledger.fabric.sdk.testutils.TestUtils.MockEnrollment;
import org.hyperledger.fabric.sdk.testutils.TestUtils.MockUser;
import org.hyperledger.fabric.sdkintegration.Util;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class ClientTest {
	private static final String CHANNEL_NAME = "mychannel";
	static HFClient hfclient = null;
	  private static final String EXPECTED_EVENT_NAME = "event";
	private static final String USER_NAME = "MockMe";
	private static final String USER_MSP_ID = "MockMSPID";
	private static final String CHAIN_CODE_FILEPATH = "sdkintegration/gocc/sample1";
	private static final String CHAIN_CODE_NAME = "mychaincode201";
	private static final String CHAIN_CODE_PATH = "github.com/example_cc";
	private static final String CHAIN_CODE_VERSION = "1";
	private static final String TEST_FIXTURES_PATH = "src/test/fixture";
	private static final String NODE_CHAIN_CODE_FILEPATH = "sdkintegration/nodecc/sample1";
	private static final String NODE_CHAIN_CODE_NAME = "mychaincodeNode3";
	private static final String NODE_CHAIN_CODE_PATH = ".";
	private static final String NODE_CHAIN_CODE_VERSION = "1";
	private static final String NODE_TEST_FIXTURES_PATH = "src/test/fixture";

	Type CHAIN_CODE_LANG = Type.GO_LANG;

	@BeforeClass
	public static void setupClient() throws Exception {
		try {
			resetConfig();
			hfclient = TestHFClient.newInstance();

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Unexpected Exception " + e.getMessage());

		}

	}

	@Test
	public void testNewChannel() {
		try {
			Channel testChannel = hfclient.newChannel(CHANNEL_NAME);
			Assert.assertTrue(testChannel != null && CHANNEL_NAME.equalsIgnoreCase(testChannel.getName()));
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Unexpected Exception " + e.getMessage());
		}
	}

	@Test(expected = InvalidArgumentException.class)
	public void testSetNullChannel() throws InvalidArgumentException {
		hfclient.newChannel(null);
		Assert.fail("Expected null channel to throw exception.");
	}

	@Test
	public void testNewPeer() {
		try {
			Peer peer = hfclient.newPeer("peer_", "grpc://localhost:7051");
			Assert.assertTrue(peer != null);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Unexpected Exception " + e.getMessage());
		}
	}

	@Test(expected = InvalidArgumentException.class)
	public void testBadURL() throws InvalidArgumentException {
		hfclient.newPeer("peer_", " ");
		Assert.fail("Expected peer with no channel throw exception");
	}

	public static void main(String[] args) {
		try {
			Logger logger = Logger.getLogger(ClientTest.class);
			logger.getRoot().addAppender(new ConsoleAppender(new SimpleLayout()));
			System.out.println("initialize logger");
			// setupClient();
			hfclient = TestHFClient.newInstance();

			Channel testChannel = hfclient.newChannel(CHANNEL_NAME);
			// Channel testChannel = hfclient.getChannel(CHANNEL_NAME);
			System.out.println("client setup success");
			try {
				Peer peer = hfclient.newPeer("peer0.org1.example.com", "grpc://10.64.217.120:7051");

				Orderer orderer = hfclient.newOrderer("orderer.example.co", "grpc://10.64.217.120:7050");
				testChannel.addPeer(peer);
				testChannel.addOrderer(orderer);
				testChannel.initialize();

				// QueryByChaincodeRequest queryByChaincodeRequest =
				// queryAllcars();
				/**
				 * query for particular car
				 * queryByChaincodeRequest.setFcn("queryCar");
				 * queryByChaincodeRequest.setArgs("CAR4");
				 */
				// changeCarOwner(testChannel, "CAR9", "Dave");
				/*
				 * Collection<ProposalResponse> collection =
				 * testChannel.queryByChaincode(queryByChaincodeRequest);
				 * Iterator<ProposalResponse> iterator = collection.iterator();
				 * while (iterator.hasNext()) { ProposalResponse
				 * proposalResponse = iterator.next();
				 * System.out.println("Quesry response"); System.out.println(new
				 * String(proposalResponse.getPayloadBytes().toByteArray()));
				 * System.out.println(proposalResponse.getMessage());
				 * System.out.println(proposalResponse.getChaincodeID());
				 * System.out.println(proposalResponse.getPayloadBytes());
				 * System.out.println(proposalResponse.getPeer()); }
				 */
				//createChainCodeGo(testChannel);
				 //instantiateChaincode(testChannel);
				//createChainCodeJava(testChannel);
				//createChainCodeNode(testChannel);
				//instantiateChaincodeNode(testChannel);
				
				
				 QueryByChaincodeRequest queryByChaincodeRequest2 =
				  queryNodeChaincode(testChannel);
				  
				  Collection<ProposalResponse> collection2 =
				  testChannel.queryByChaincode(queryByChaincodeRequest2);
				  Iterator<ProposalResponse> iterator2 =
				  collection2.iterator(); while (iterator2.hasNext()) {
				  ProposalResponse proposalResponse = iterator2.next();
				  System.out.println("Quesry response"); System.out.println(new
				  String(proposalResponse.getPayloadBytes().toByteArray()));
				  System.out.println(proposalResponse.getMessage());
				  System.out.println(proposalResponse.getChaincodeID());
				  System.out.println(proposalResponse.getPayloadBytes());
				  System.out.println(proposalResponse.getPeer()); }
				 

				// Assert.assertTrue(peer != null);
			} catch (Exception e) {
				e.printStackTrace();
				// Assert.fail("Unexpected Exception " + e.getMessage());
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static QueryByChaincodeRequest queryMychaincode() {
		QueryByChaincodeRequest queryByChaincodeRequest = QueryByChaincodeRequest
				.newInstance(hfclient.getUserContext());
		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName(CHAIN_CODE_NAME).build();
		queryByChaincodeRequest.setChaincodeID(chaincodeID);
		queryByChaincodeRequest.setArgs("B");
		queryByChaincodeRequest.setFcn("query");
		return queryByChaincodeRequest;

	}

	public static void createChainCodeGo(Channel testChannel)
			throws InvalidArgumentException, ProposalException, IOException {
		InstallProposalRequest installProposalRequest = hfclient.newInstallProposalRequest();

		installProposalRequest.setChaincodeLanguage(Type.GO_LANG);
		installProposalRequest.setChaincodeVersion(CHAIN_CODE_VERSION);
		
		 String chaincodeEventListenerHandle = testChannel.registerChaincodeEventListener(Pattern.compile(".*"),
                 Pattern.compile(Pattern.quote(EXPECTED_EVENT_NAME)),
                new ChaincodeEventListenerImpl());
		installProposalRequest.setChaincodeName(CHAIN_CODE_NAME);

		// ChaincodeID chaincodeID =
		// ChaincodeID.newBuilder().setName("mychaincode").build();

		// installProposalRequest.setChaincodeID(chaincodeID);

		// installProposalRequest.setChaincodePath(
		// Paths.get("C:\\Users\\vikash.agrawal\\Desktop\\fabric-sdk-java\\src\\test\\fixture\\sdkintegration\\gocc\\sample1\\src\\github.com\\example_cc\\example_cc.go").toString());
		// installProposalRequest.setChaincodeInputStream(new
		// FileInputStream(
		// "C:\\Users\\vikash.agrawal\\Desktop\\fabric-sdk-java\\src\\test\\fixture\\sdkintegration\\gocc\\sample1\\src\\github.com\\example_cc\\example_cc.go"));
		// installProposalRequest.setChaincodeSourceLocation(new
		// File("src/org/hyperledger/fabric/sdk/ChainCodeImpl.java"));
		File file = new File("src/test/fixture/sdkintegration/gocc/sample1");
		System.out.println("file exists " + file.exists());
		System.out.println(Paths.get(TEST_FIXTURES_PATH, CHAIN_CODE_FILEPATH, "src", CHAIN_CODE_PATH));
		installProposalRequest.setChaincodePath("github.com/example_cc");
		// installProposalRequest.setChaincodeSourceLocation(file);
		/*
		 * installProposalRequest.setChaincodeInputStream(Util.
		 * generateTarGzInputStream( Paths.get(file.toString()).toFile(),
		 * "/chaincode/input/src/github.com/example_cc"));
		 */
		installProposalRequest.setChaincodeInputStream(Util.generateTarGzInputStream(
				(Paths.get(TEST_FIXTURES_PATH, CHAIN_CODE_FILEPATH, "src", CHAIN_CODE_PATH).toFile()),
				Paths.get("src", CHAIN_CODE_PATH).toString()));
		// installProposalRequest.setChaincodeInputStream(Util.generateTarGzInputStream(
		// (Paths.get(TEST_FIXTURES_PATH, CHAIN_CODE_FILEPATH, "src",
		// CHAIN_CODE_PATH).toFile()),
		// Paths.get("src", CHAIN_CODE_PATH).toString()));
		/*
		 * installProposalRequest
		 * .setChaincodeSourceLocation(Paths.get(TEST_FIXTURES_PATH,
		 * CHAIN_CODE_FILEPATH).toFile());
		 */

		Collection<ProposalResponse> proposalResponse = testChannel.sendInstallProposal(installProposalRequest);

		Iterator<ProposalResponse> iterator = proposalResponse.iterator();

		while (iterator.hasNext()) {
			ProposalResponse proposalResponse2 = iterator.next();
			System.out.println(new String(proposalResponse2.getPayloadBytes().toByteArray()));
			System.out.println(proposalResponse2.getMessage());
			System.out.println(proposalResponse2.getChaincodeID());
			System.out.println(proposalResponse2.getPayloadBytes());

		}
	}
	
	public static QueryByChaincodeRequest queryNodeChaincode(Channel testChannel){
		QueryByChaincodeRequest queryByChaincodeRequest = QueryByChaincodeRequest
				.newInstance(hfclient.getUserContext());
		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName(NODE_CHAIN_CODE_NAME).build();
		queryByChaincodeRequest.setChaincodeID(chaincodeID);
		queryByChaincodeRequest.setArgs("B");
		queryByChaincodeRequest.setFcn("query");
		return queryByChaincodeRequest;
	}
	public static void createChainCodeNode(Channel testChannel)
			throws InvalidArgumentException, ProposalException, IOException {
		InstallProposalRequest installProposalRequest = hfclient.newInstallProposalRequest();

		installProposalRequest.setChaincodeLanguage(Type.NODE);
		installProposalRequest.setChaincodeVersion(CHAIN_CODE_VERSION);
		
		 String chaincodeEventListenerHandle = testChannel.registerChaincodeEventListener(Pattern.compile(".*"),
                 Pattern.compile(Pattern.quote(EXPECTED_EVENT_NAME)),
                new ChaincodeEventListenerImpl());
		installProposalRequest.setChaincodeName(NODE_CHAIN_CODE_NAME);

		// ChaincodeID chaincodeID =
		// ChaincodeID.newBuilder().setName("mychaincode").build();

		// installProposalRequest.setChaincodeID(chaincodeID);

		// installProposalRequest.setChaincodePath(
		// Paths.get("C:\\Users\\vikash.agrawal\\Desktop\\fabric-sdk-java\\src\\test\\fixture\\sdkintegration\\gocc\\sample1\\src\\github.com\\example_cc\\example_cc.go").toString());
		// installProposalRequest.setChaincodeInputStream(new
		// FileInputStream(
		// "C:\\Users\\vikash.agrawal\\Desktop\\fabric-sdk-java\\src\\test\\fixture\\sdkintegration\\gocc\\sample1\\src\\github.com\\example_cc\\example_cc.go"));
		// installProposalRequest.setChaincodeSourceLocation(new
		// File("src/org/hyperledger/fabric/sdk/ChainCodeImpl.java"));
		File file = new File("src/test/fixture/sdkintegration/gocc/sample1");
		System.out.println("file exists " + file.exists());
		System.out.println(Paths.get(NODE_TEST_FIXTURES_PATH, NODE_CHAIN_CODE_FILEPATH, "src", NODE_CHAIN_CODE_PATH));

		// installProposalRequest.setChaincodeSourceLocation(file);
		/*
		 * installProposalRequest.setChaincodeInputStream(Util.
		 * generateTarGzInputStream( Paths.get(file.toString()).toFile(),
		 * "/chaincode/input/src/github.com/example_cc"));
		 */
		installProposalRequest.setChaincodeInputStream(Util.generateTarGzInputStream(
				(Paths.get(NODE_TEST_FIXTURES_PATH, NODE_CHAIN_CODE_FILEPATH).toFile()),
				Paths.get("src", NODE_CHAIN_CODE_PATH).toString()));
		// installProposalRequest.setChaincodeInputStream(Util.generateTarGzInputStream(
		// (Paths.get(TEST_FIXTURES_PATH, CHAIN_CODE_FILEPATH, "src",
		// CHAIN_CODE_PATH).toFile()),
		// Paths.get("src", CHAIN_CODE_PATH).toString()));
		/*
		 * installProposalRequest
		 * .setChaincodeSourceLocation(Paths.get(TEST_FIXTURES_PATH,
		 * CHAIN_CODE_FILEPATH).toFile());
		 */

		Collection<ProposalResponse> proposalResponse = testChannel.sendInstallProposal(installProposalRequest);

		Iterator<ProposalResponse> iterator = proposalResponse.iterator();

		while (iterator.hasNext()) {
			ProposalResponse proposalResponse2 = iterator.next();
			System.out.println(new String(proposalResponse2.getPayloadBytes().toByteArray()));
			System.out.println(proposalResponse2.getMessage());
			System.out.println(proposalResponse2.getChaincodeID());
			System.out.println(proposalResponse2.getPayloadBytes());

		}
	}
	public static void createChainCodeJava(Channel testChannel)
			throws InvalidArgumentException, ProposalException, IOException {
		InstallProposalRequest installProposalRequest = hfclient.newInstallProposalRequest();

		installProposalRequest.setChaincodeLanguage(Type.JAVA);
		installProposalRequest.setChaincodeVersion(CHAIN_CODE_VERSION);

		installProposalRequest.setChaincodeName(CHAIN_CODE_NAME);

		// ChaincodeID chaincodeID =
		// ChaincodeID.newBuilder().setName("mychaincode").build();

		// installProposalRequest.setChaincodeID(chaincodeID);

		// installProposalRequest.setChaincodePath(
		// Paths.get("C:\\Users\\vikash.agrawal\\Desktop\\fabric-sdk-java\\src\\test\\fixture\\sdkintegration\\gocc\\sample1\\src\\github.com\\example_cc\\example_cc.go").toString());
		// installProposalRequest.setChaincodeInputStream(new
		// FileInputStream(
		// "C:\\Users\\vikash.agrawal\\Desktop\\fabric-sdk-java\\src\\test\\fixture\\sdkintegration\\gocc\\sample1\\src\\github.com\\example_cc\\example_cc.go"));
		// installProposalRequest.setChaincodeSourceLocation(new
		// File("src/org/hyperledger/fabric/sdk/ChainCodeImpl.java"));
		File file = new File("/src/org/hyperledger/fabric/sdk/ChainCodeImpl.java");
		System.out.println("file exists " + file.exists());
		System.out.println(Paths.get(TEST_FIXTURES_PATH, CHAIN_CODE_FILEPATH, "src", CHAIN_CODE_PATH));
		
		installProposalRequest.setChaincodeInputStream(
				Util.generateTarGzInputStream((Paths.get(TEST_FIXTURES_PATH, CHAIN_CODE_FILEPATH).toFile()), "src"));
		/*
		 * installProposalRequest.setChaincodeInputStream(Util.
		 * generateTarGzInputStream( Paths.get(file.toString()).toFile(),
		 * "/chaincode/input/src/github.com/example_cc"));
		 */
		/*
		 * installProposalRequest.setChaincodeInputStream(Util.
		 * generateTarGzInputStream( (Paths.get(TEST_FIXTURES_PATH,
		 * CHAIN_CODE_FILEPATH, "src", CHAIN_CODE_PATH).toFile()),
		 * Paths.get("src", CHAIN_CODE_PATH).toString()));
		 */
		// installProposalRequest.setChaincodeInputStream(Util.generateTarGzInputStream(
		// (Paths.get(TEST_FIXTURES_PATH, CHAIN_CODE_FILEPATH, "src",
		// CHAIN_CODE_PATH).toFile()),
		// Paths.get("src", CHAIN_CODE_PATH).toString()));
		/*
		 * installProposalRequest
		 * .setChaincodeSourceLocation(Paths.get(TEST_FIXTURES_PATH,
		 * CHAIN_CODE_FILEPATH).toFile());
		 */
		installProposalRequest.setChaincodePath(null);
		Collection<ProposalResponse> proposalResponse = testChannel.sendInstallProposal(installProposalRequest);

		Iterator<ProposalResponse> iterator = proposalResponse.iterator();

		while (iterator.hasNext()) {
			ProposalResponse proposalResponse2 = iterator.next();
			System.out.println(new String(proposalResponse2.getPayloadBytes().toByteArray()));
			System.out.println(proposalResponse2.getMessage());
			System.out.println(proposalResponse2.getChaincodeID());
			System.out.println(proposalResponse2.getPayloadBytes());

		}
	}

	public static void instantiateChaincode(Channel testChannel)
			throws InvalidArgumentException, ProposalException, ChaincodeEndorsementPolicyParseException, IOException,
			InterruptedException, ExecutionException, TimeoutException {
		InstantiateProposalRequest instantiateProposalRequest = hfclient.newInstantiationProposalRequest();
		instantiateProposalRequest.setChaincodeName(CHAIN_CODE_NAME);
		instantiateProposalRequest.setChaincodePath("github.com/example_cc");
		instantiateProposalRequest.setArgs("A", "100", "B", "200");
		instantiateProposalRequest.setChaincodeLanguage(Type.GO_LANG);
		instantiateProposalRequest.setChaincodeVersion(CHAIN_CODE_VERSION);
		Map<String, byte[]> tm = new HashMap<>();
		tm.put("HyperLedgerFabric", "InstantiateProposalRequest:JavaSDK".getBytes(UTF_8));
		tm.put("method", "InstantiateProposalRequest".getBytes(UTF_8));
		instantiateProposalRequest.setTransientMap(tm);
		instantiateProposalRequest.setProposalWaitTime(TestConfig.getConfig().getProposalWaitTime());
		instantiateProposalRequest.setTransientMap(tm);
		ChaincodeEndorsementPolicy chaincodeEndorsementPolicy = new ChaincodeEndorsementPolicy();
		chaincodeEndorsementPolicy
				.fromYamlFile(new File(TEST_FIXTURES_PATH + "/sdkintegration/chaincodeendorsementpolicy.yaml"));
		instantiateProposalRequest.setChaincodeEndorsementPolicy(chaincodeEndorsementPolicy);
		Collection<ProposalResponse> proposalResponse = testChannel
				.sendInstantiationProposal(instantiateProposalRequest);

		Iterator<ProposalResponse> iterator = proposalResponse.iterator();

		while (iterator.hasNext()) {
			ProposalResponse proposalResponse2 = iterator.next();
			System.out.println(new String(proposalResponse2.getPayloadBytes().toByteArray()));
			System.out.println(proposalResponse2.getMessage());
			System.out.println(proposalResponse2.getChaincodeID());
			System.out.println(proposalResponse2.getPayloadBytes());

		}

		TestConfig testConfig = TestConfig.getConfig();

		testChannel.sendTransaction(proposalResponse, hfclient.getUserContext()).thenApply(transactionEvent -> {
			try {

				assertTrue(transactionEvent.isValid()); // must be valid to be
														// here.
				System.out
						.println("Finished transaction with transaction id %s " + transactionEvent.getTransactionID());
				String testTxID = transactionEvent.getTransactionID(); // used
																		// in
																		// the
				// channel
				// queries later

				////////////////////////////
				// Send Query Proposal to all peers
				//
				int delta = 30;
				String expect = "" + (300 + delta);
				System.out.println("Now query chaincode for the value of b.");
				QueryByChaincodeRequest queryByChaincodeRequest = hfclient.newQueryProposalRequest();
				queryByChaincodeRequest.setArgs(new String[] { "b" });
				queryByChaincodeRequest.setFcn("query");
				queryByChaincodeRequest.setChaincodeName(CHAIN_CODE_NAME);

				Map<String, byte[]> tm2 = new HashMap<>();
				tm2.put("HyperLedgerFabric", "QueryByChaincodeRequest:JavaSDK".getBytes(UTF_8));
				tm2.put("method", "QueryByChaincodeRequest".getBytes(UTF_8));
				queryByChaincodeRequest.setTransientMap(tm2);

				Collection<ProposalResponse> queryProposals = testChannel.queryByChaincode(queryByChaincodeRequest);
				for (ProposalResponse proposalResponse2 : queryProposals) {
					if (!proposalResponse2.isVerified()
							|| proposalResponse2.getStatus() != ProposalResponse.Status.SUCCESS) {
						fail("Failed query proposal from peer " + proposalResponse2.getPeer().getName() + " status: "
								+ proposalResponse2.getStatus() + ". Messages: " + proposalResponse2.getMessage()
								+ ". Was verified : " + proposalResponse2.isVerified());
					} else {
						String payload = proposalResponse2.getProposalResponse().getResponse().getPayload()
								.toStringUtf8();
						System.out.println(
								"Query payload of b from peer %s returned  " + proposalResponse2.getPeer().getName());
						assertEquals(payload, expect);
					}
				}

				return null;
			} catch (Exception e) {
				System.err.println("Caught exception while running query");
				e.printStackTrace();
				fail("Failed during chaincode query with error : " + e.getMessage());
			}

			return null;
		}).exceptionally(e -> {
			if (e instanceof TransactionEventException) {
				BlockEvent.TransactionEvent te = ((TransactionEventException) e).getTransactionEvent();
				if (te != null) {
					throw new AssertionError(
							format("Transaction with txid %s failed. %s", te.getTransactionID(), e.getMessage()), e);
				}
			}

			throw new AssertionError(format("Test failed with %s exception %s", e.getClass().getName(), e.getMessage()),
					e);

		}).get(testConfig.getTransactionWaitTime(), TimeUnit.SECONDS);
	}

	
	public static void instantiateChaincodeNode(Channel testChannel)
			throws InvalidArgumentException, ProposalException, ChaincodeEndorsementPolicyParseException, IOException,
			InterruptedException, ExecutionException, TimeoutException {
		InstantiateProposalRequest instantiateProposalRequest = hfclient.newInstantiationProposalRequest();
		instantiateProposalRequest.setChaincodeName(NODE_CHAIN_CODE_NAME);
		//instantiateProposalRequest.setChaincodePath("github.com/example_cc");
		instantiateProposalRequest.setArgs("A", "100", "B", "200");
		instantiateProposalRequest.setChaincodeLanguage(Type.NODE);
		instantiateProposalRequest.setChaincodeVersion(CHAIN_CODE_VERSION);
		Map<String, byte[]> tm = new HashMap<>();
		tm.put("HyperLedgerFabric", "InstantiateProposalRequest:NodeSDK".getBytes(UTF_8));
		tm.put("method", "InstantiateProposalRequest".getBytes(UTF_8));
		instantiateProposalRequest.setTransientMap(tm);
		instantiateProposalRequest.setProposalWaitTime(TestConfig.getConfig().getProposalWaitTime());
		instantiateProposalRequest.setTransientMap(tm);
		ChaincodeEndorsementPolicy chaincodeEndorsementPolicy = new ChaincodeEndorsementPolicy();
		chaincodeEndorsementPolicy
				.fromYamlFile(new File(TEST_FIXTURES_PATH + "/sdkintegration/chaincodeendorsementpolicy.yaml"));
		instantiateProposalRequest.setChaincodeEndorsementPolicy(chaincodeEndorsementPolicy);
		Collection<ProposalResponse> proposalResponse = testChannel
				.sendInstantiationProposal(instantiateProposalRequest);

		Iterator<ProposalResponse> iterator = proposalResponse.iterator();

		while (iterator.hasNext()) {
			ProposalResponse proposalResponse2 = iterator.next();
			System.out.println(new String(proposalResponse2.getPayloadBytes().toByteArray()));
			System.out.println(proposalResponse2.getMessage());
			System.out.println(proposalResponse2.getChaincodeID());
			System.out.println(proposalResponse2.getPayloadBytes());

		}

		TestConfig testConfig = TestConfig.getConfig();

		testChannel.sendTransaction(proposalResponse, hfclient.getUserContext()).thenApply(transactionEvent -> {
			try {

				assertTrue(transactionEvent.isValid()); // must be valid to be
														// here.
				System.out
						.println("Finished transaction with transaction id %s " + transactionEvent.getTransactionID());
				String testTxID = transactionEvent.getTransactionID(); // used
																		// in
																		// the
				// channel
				// queries later

				////////////////////////////
				// Send Query Proposal to all peers
				//
				int delta = 30;
				String expect = "" + (300 + delta);
				System.out.println("Now query chaincode for the value of b.");
				QueryByChaincodeRequest queryByChaincodeRequest = hfclient.newQueryProposalRequest();
				queryByChaincodeRequest.setArgs(new String[] { "b" });
				queryByChaincodeRequest.setFcn("query");
				ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName(NODE_CHAIN_CODE_NAME).build();
				queryByChaincodeRequest.setChaincodeID(chaincodeID);

				Map<String, byte[]> tm2 = new HashMap<>();
				tm2.put("HyperLedgerFabric", "QueryByChaincodeRequest:NodeSDK".getBytes(UTF_8));
				tm2.put("method", "QueryByChaincodeRequest".getBytes(UTF_8));
				queryByChaincodeRequest.setTransientMap(tm2);

				Collection<ProposalResponse> queryProposals = testChannel.queryByChaincode(queryByChaincodeRequest);
				for (ProposalResponse proposalResponse2 : queryProposals) {
					if (!proposalResponse2.isVerified()
							|| proposalResponse2.getStatus() != ProposalResponse.Status.SUCCESS) {
						fail("Failed query proposal from peer " + proposalResponse2.getPeer().getName() + " status: "
								+ proposalResponse2.getStatus() + ". Messages: " + proposalResponse2.getMessage()
								+ ". Was verified : " + proposalResponse2.isVerified());
					} else {
						String payload = proposalResponse2.getProposalResponse().getResponse().getPayload()
								.toStringUtf8();
						System.out.println(
								"Query payload of b from peer %s returned  " + proposalResponse2.getPeer().getName());
						//assertEquals(payload, expect);
					}
				}

				return null;
			} catch (Exception e) {
				System.err.println("Caught exception while running query");
				e.printStackTrace();
				fail("Failed during chaincode query with error : " + e.getMessage());
			}

			return null;
		}).exceptionally(e -> {
			if (e instanceof TransactionEventException) {
				BlockEvent.TransactionEvent te = ((TransactionEventException) e).getTransactionEvent();
				if (te != null) {
					throw new AssertionError(
							format("Transaction with txid %s failed. %s", te.getTransactionID(), e.getMessage()), e);
				}
			}

			throw new AssertionError(format("Test failed with %s exception %s", e.getClass().getName(), e.getMessage()),
					e);

		}).get(testConfig.getTransactionWaitTime(), TimeUnit.SECONDS);
	}
	public static void changeCarOwner(Channel testChannel, String... args)
			throws ProposalException, InvalidArgumentException {
		TransactionProposalRequest transactionProposalRequest = hfclient.newTransactionProposalRequest();
		;

		transactionProposalRequest.setFcn("changeCarOwner");

		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName("fabcar").build();

		transactionProposalRequest.setChaincodeID(chaincodeID);

		transactionProposalRequest.setArgs(args);
		// transactionProposalRequest.setArgs("CAR11", "Chevy1", "Volt1",
		// "Red1", "Nick1");

		Collection<ProposalResponse> proposalResponses = testChannel
				.sendTransactionProposal(transactionProposalRequest);

		testChannel.sendTransaction(proposalResponses, hfclient.getUserContext());
	}

	public static void createcar(Channel testChannel, String... args)
			throws ProposalException, InvalidArgumentException {
		TransactionProposalRequest transactionProposalRequest = hfclient.newTransactionProposalRequest();
		;

		transactionProposalRequest.setFcn("createCar");

		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName("fabcar").build();

		transactionProposalRequest.setChaincodeID(chaincodeID);

		transactionProposalRequest.setArgs(args);
		// transactionProposalRequest.setArgs("CAR11", "Chevy1", "Volt1",
		// "Red1", "Nick1");

		Collection<ProposalResponse> proposalResponses = testChannel
				.sendTransactionProposal(transactionProposalRequest);

		testChannel.sendTransaction(proposalResponses, hfclient.getUserContext());
	}

	public static QueryByChaincodeRequest queryAllcars() {
		QueryByChaincodeRequest queryByChaincodeRequest = QueryByChaincodeRequest
				.newInstance(hfclient.getUserContext());
		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName("fabcar").build();
		queryByChaincodeRequest.setChaincodeID(chaincodeID);
		queryByChaincodeRequest.setFcn("queryAllCars");
		return queryByChaincodeRequest;
	}

	public static QueryByChaincodeRequest queryOnecar(String carname) {
		QueryByChaincodeRequest queryByChaincodeRequest = QueryByChaincodeRequest
				.newInstance(hfclient.getUserContext());
		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName("fabcar").build();
		queryByChaincodeRequest.setChaincodeID(chaincodeID);
		queryByChaincodeRequest.setFcn("queryCar");
		queryByChaincodeRequest.setArgs(carname);
		return queryByChaincodeRequest;
	}

	@Test
	public void testNewOrderer() {
		try {
			Orderer orderer = hfclient.newOrderer("xx", "grpc://localhost:5005");
			Assert.assertTrue(orderer != null);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Unexpected Exception " + e.getMessage());
		}
	}

	@Test(expected = InvalidArgumentException.class)
	public void testBadAddress() throws InvalidArgumentException {
		hfclient.newOrderer("xx", "xxxxxx");
		Assert.fail("Orderer allowed setting bad URL.");
	}

	@Test(expected = InvalidArgumentException.class)
	public void testBadCryptoSuite() throws InvalidArgumentException {
		HFClient.createNewInstance().newOrderer("xx", "xxxxxx");
		Assert.fail("Orderer allowed setting no cryptoSuite");
	}

	@Test
	public void testGoodMockUser() throws Exception {
		HFClient client = HFClient.createNewInstance();
		client.setCryptoSuite(CryptoSuite.Factory.getCryptoSuite());
		client.setUserContext(TestUtils.getMockUser(USER_NAME, USER_MSP_ID));
		Orderer orderer = hfclient.newOrderer("justMockme", "grpc://localhost:99"); // test
																					// mock
																					// should
																					// work.
		Assert.assertNotNull(orderer);

	}

	@Test(expected = InvalidArgumentException.class)
	public void testBadUserContextNull() throws Exception {
		HFClient client = HFClient.createNewInstance();
		client.setCryptoSuite(CryptoSuite.Factory.getCryptoSuite());

		client.setUserContext(null);

	}

	@Test(expected = InvalidArgumentException.class)
	public void testBadUserNameNull() throws Exception {
		HFClient client = HFClient.createNewInstance();
		client.setCryptoSuite(CryptoSuite.Factory.getCryptoSuite());

		MockUser mockUser = TestUtils.getMockUser(null, USER_MSP_ID);

		client.setUserContext(mockUser);

	}

	@Test(expected = InvalidArgumentException.class)
	public void testBadUserNameEmpty() throws Exception {
		HFClient client = HFClient.createNewInstance();
		client.setCryptoSuite(CryptoSuite.Factory.getCryptoSuite());

		MockUser mockUser = TestUtils.getMockUser("", USER_MSP_ID);

		client.setUserContext(mockUser);

	}

	@Test(expected = InvalidArgumentException.class)
	public void testBadUserMSPIDNull() throws Exception {
		HFClient client = HFClient.createNewInstance();
		client.setCryptoSuite(CryptoSuite.Factory.getCryptoSuite());

		MockUser mockUser = TestUtils.getMockUser(USER_NAME, null);

		client.setUserContext(mockUser);

	}

	@Test(expected = InvalidArgumentException.class)
	public void testBadUserMSPIDEmpty() throws Exception {
		HFClient client = HFClient.createNewInstance();
		client.setCryptoSuite(CryptoSuite.Factory.getCryptoSuite());

		MockUser mockUser = TestUtils.getMockUser(USER_NAME, "");

		client.setUserContext(mockUser);

	}

	@Test(expected = InvalidArgumentException.class)
	public void testBadEnrollmentNull() throws Exception {
		HFClient client = HFClient.createNewInstance();
		client.setCryptoSuite(CryptoSuite.Factory.getCryptoSuite());

		MockUser mockUser = TestUtils.getMockUser(USER_NAME, USER_MSP_ID);
		mockUser.setEnrollment(null);

		client.setUserContext(mockUser);

	}

	@Test(expected = InvalidArgumentException.class)
	public void testBadEnrollmentBadCert() throws Exception {
		HFClient client = HFClient.createNewInstance();
		client.setCryptoSuite(CryptoSuite.Factory.getCryptoSuite());

		MockUser mockUser = TestUtils.getMockUser(USER_NAME, USER_MSP_ID);

		MockEnrollment mockEnrollment = TestUtils.getMockEnrollment(null);
		mockUser.setEnrollment(mockEnrollment);

		client.setUserContext(mockUser);

	}

	@Test(expected = InvalidArgumentException.class)
	public void testBadEnrollmentBadKey() throws Exception {
		HFClient client = HFClient.createNewInstance();
		client.setCryptoSuite(CryptoSuite.Factory.getCryptoSuite());

		MockUser mockUser = TestUtils.getMockUser(USER_NAME, USER_MSP_ID);

		MockEnrollment mockEnrollment = TestUtils.getMockEnrollment(null, "mockCert");
		mockUser.setEnrollment(mockEnrollment);

		client.setUserContext(mockUser);

	}

	@Test // (expected = InvalidArgumentException.class)
	@Ignore
	public void testCryptoFactory() throws Exception {
		try {
			resetConfig();
			Assert.assertNotNull(Config.getConfig().getDefaultCryptoSuiteFactory());

			HFClient client = HFClient.createNewInstance();

			client.setCryptoSuite(CryptoSuite.Factory.getCryptoSuite());

			MockUser mockUser = TestUtils.getMockUser(USER_NAME, USER_MSP_ID);

			MockEnrollment mockEnrollment = TestUtils.getMockEnrollment(null, "mockCert");
			mockUser.setEnrollment(mockEnrollment);

			client.setUserContext(mockUser);
		} finally {
			System.getProperties().remove("org.hyperledger.fabric.sdk.crypto.default_crypto_suite_factory");

		}

	}

}
